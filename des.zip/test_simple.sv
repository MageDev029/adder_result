`timescale 1ns / 1ps

module test_simple;
    logic clk, resetn;
    logic [31:0] imem_inst;
    logic [31:0] mem_dat;
    logic mem_ack;
    
    // Instantiate the processor
    rv32i_top dut (
        .clk_i(clk),
        .resetn_i(resetn),
        .illegal_inst_o(),
        .imem_addr_o(),
        .imem_inst_i(imem_inst),
        .mem_addr_o(),
        .mem_dat_o(),
        .mem_dat_i(mem_dat),
        .mem_write_o(),
        .mem_wstrb_o(),
        .mem_read_o(),
        .mem_ack_i(mem_ack)
    );
    
    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end
    
    // Test sequence
    initial begin
        resetn = 0;
        imem_inst = 32'h00000013; // NOP (ADDI x0, x0, 0)
        mem_dat = 32'h0;
        mem_ack = 1;
        
        #20 resetn = 1;
        
        // Test a simple ADDI instruction
        imem_inst = 32'h00100093; // ADDI x1, x0, 1
        
        #100;
        
        $display("Test completed");
        $finish;
    end
    
endmodule
