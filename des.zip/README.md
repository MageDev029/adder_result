# RV32I 5-Stage Pipelined Processor

This repository contains a complete 5-stage pipelined implementation of the RV32I instruction set architecture.

## Architecture Overview

The processor implements a classic 5-stage RISC pipeline:

1. **IF (Instruction Fetch)** - Fetches instructions from instruction memory
2. **ID (Instruction Decode)** - Decodes instructions and reads register file
3. **EX (Execute)** - Performs ALU operations and branch resolution
4. **MEM (Memory)** - Handles data memory access
5. **WB (Writeback)** - Writes results back to register file

## File Structure

```
src/
├── rv32i_top.sv              # Main top-level module
├── if_stage.sv               # Instruction fetch stage
├── id_stage.sv               # Instruction decode stage
├── ex_stage.sv               # Execute stage
├── mem_stage.sv              # Memory access stage
├── wb_stage.sv               # Writeback stage
├── register_file.sv          # Register file module
├── pipeline_registers.sv     # Pipeline register modules
├── hazard_unit.sv            # Hazard detection unit
├── forwarding_unit.sv        # Data forwarding unit
├── rv32i_pipelined_top.sv    # Alternative pipelined top module
└── rv32i_top_single_cycle.sv # Original single-cycle implementation
```

## Key Features

- **5-stage pipeline** with proper hazard detection and forwarding
- **Complete RV32I instruction set** support
- **Data forwarding** to minimize pipeline stalls
- **Load-use hazard detection** with pipeline stalling
- **Branch prediction** with pipeline flushing
- **Tracer integration** for debugging and verification
- **Same interface** as original single-cycle implementation

## Usage

### Using RTL File Lists

Two RTL file lists are provided:

- `rtl.f` - Simple file list for basic usage
- `rtl_complete.f` - Comprehensive file list with documentation

### Compilation

Use the provided Makefile for common tasks:

```bash
# Show help
make help

# List all RTL files
make list-files

# Check syntax (requires iverilog)
make check-syntax

# Clean generated files
make clean
```

### Synthesis Tools

The design is compatible with most modern synthesis tools:

- **Vivado**: Use `rtl.f` with `read_verilog -f rtl.f`
- **Quartus**: Import files from `rtl.f`
- **Design Compiler**: Use `rtl.f` with `analyze -f rtl.f`
- **iverilog**: Use `iverilog -f rtl.f`

## Pipeline Details

### Hazard Handling

The processor implements comprehensive hazard detection:

1. **Data Hazards**: Resolved using data forwarding from MEM and WB stages
2. **Load-Use Hazards**: Detected and resolved with pipeline stalling
3. **Control Hazards**: Branch instructions cause pipeline flushing

### Forwarding Paths

- **EX/MEM → EX**: Forward ALU results
- **MEM/WB → EX**: Forward memory data or ALU results
- **Priority**: MEM stage forwarding takes precedence over WB stage

### Supported Instructions

The processor supports all RV32I instructions:

- **R-type**: ADD, SUB, SLL, SLT, SLTU, XOR, SRL, SRA, OR, AND
- **I-type**: ADDI, SLTI, SLTIU, XORI, ORI, ANDI, SLLI, SRLI, SRAI, LW, JALR
- **S-type**: SW, SH, SB
- **B-type**: BEQ, BNE, BLT, BGE, BLTU, BGEU
- **U-type**: LUI, AUIPC
- **J-type**: JAL

## Interface

The processor maintains the same interface as the original single-cycle implementation:

```systemverilog
module rv32i_top (
    input  logic        clk_i,
    input  logic        resetn_i,
    output logic        illegal_inst_o,
    output logic [31:0] imem_addr_o,
    input  logic [31:0] imem_inst_i,
    output logic [31:0] mem_addr_o,
    output logic [31:0] mem_dat_o,
    input  logic [31:0] mem_dat_i,
    output logic        mem_write_o,
    output logic [3:0]  mem_wstrb_o,
    output logic        mem_read_o,
    input  logic        mem_ack_i
);
```

## Verification

The design includes tracer integration for formal verification:

- Enable with `define tracer` compilation flag
- Provides RISC-V Formal Interface (RVFI) signals
- Compatible with RISC-V formal verification frameworks

## Performance

The pipelined implementation provides significant performance improvements:

- **Throughput**: Up to 5x improvement over single-cycle implementation
- **CPI**: Close to 1.0 for most instruction sequences
- **Hazard Penalties**: Minimal due to effective forwarding and hazard detection

## License

This implementation is provided as-is for educational and research purposes.
