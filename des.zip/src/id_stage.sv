`timescale 1ns / 1ps

module id_stage (
    input  logic        clk_i,
    input  logic        resetn_i,
    input  logic [31:0] instruction_i,
    input  logic [31:0] pc_i,
    input  logic [31:0] pc_plus4_i,
    input  logic        id_valid_i,
    input  logic        stall_i,
    input  logic        flush_i,
    // Register file interface
    input  logic [31:0] reg_data1_i,
    input  logic [31:0] reg_data2_i,
    // Control signals
    output logic        reg_write_o,
    output logic        mem_to_reg_o,
    output logic        mem_write_o,
    output logic        mem_read_o,
    output logic        alu_src_o,
    output logic [3:0]  alu_control_o,
    output logic        branch_o,
    output logic        jump_o,
    output logic        pc_src_o,
    // Data outputs
    output logic [31:0] pc_o,
    output logic [31:0] pc_plus4_o,
    output logic [31:0] immediate_o,
    output logic [31:0] reg_data1_o,
    output logic [31:0] reg_data2_o,
    output logic [4:0]  rs1_addr_o,
    output logic [4:0]  rs2_addr_o,
    output logic [4:0]  rd_addr_o,
    output logic [31:0] instruction_o,
    output logic        id_valid_o,
    // Hazard detection
    output logic        rs1_read_o,
    output logic        rs2_read_o
);

    // Instruction fields
    logic [6:0]  opcode;
    logic [4:0]  rs1, rs2, rd;
    logic [2:0]  funct3;
    logic [6:0]  funct7;
    logic [31:0] immediate;
    
    // Control signals
    logic reg_write, mem_to_reg, mem_write, mem_read;
    logic alu_src, branch, jump, pc_src;
    logic [3:0] alu_control;
    
    // Extract instruction fields
    assign opcode = instruction_i[6:0];
    assign rs1 = instruction_i[19:15];
    assign rs2 = instruction_i[24:20];
    assign rd = instruction_i[11:7];
    assign funct3 = instruction_i[14:12];
    assign funct7 = instruction_i[31:25];
    
    // Immediate generation
    always_comb begin
        case (opcode)
            7'b0010011,            // I-type (ADDI, etc.)
            7'b0000011,            // I-type (LW, LB, LH, LBU, LHU)
            7'b1100111:            // I-type (JALR)
                immediate = {{20{instruction_i[31]}}, instruction_i[31:20]};
            7'b0100011: immediate = {{20{instruction_i[31]}}, instruction_i[31:25], instruction_i[11:7]}; // S-type
            7'b1100011: immediate = {{20{instruction_i[31]}}, instruction_i[7], instruction_i[30:25], instruction_i[11:8], 1'b0}; // B-type
            7'b0110111: immediate = {instruction_i[31:12], 12'b0}; // U-type (LUI)
            7'b0010111: immediate = {instruction_i[31:12], 12'b0}; // U-type (AUIPC)
            7'b1101111: immediate = {{12{instruction_i[31]}}, instruction_i[19:12], instruction_i[20], instruction_i[30:21], 1'b0}; // J-type (JAL)
            default: immediate = 32'h0;
        endcase
    end
    
    // Control unit
    always_comb begin
        // Default values
        reg_write = 1'b0;
        mem_to_reg = 1'b0;
        mem_write = 1'b0;
        mem_read = 1'b0;
        alu_src = 1'b0;
        alu_control = 4'b0000;
        branch = 1'b0;
        jump = 1'b0;
        pc_src = 1'b0;
        
        case (opcode)
            7'b0010011: begin // I-type (ADDI, etc.)
                alu_src = 1'b1;
                reg_write = 1'b1;
                case (funct3)
                    3'b000: alu_control = 4'b0000; // ADDI
                    3'b001: alu_control = 4'b0001; // SLLI
                    3'b010: alu_control = 4'b0010; // SLTI
                    3'b011: alu_control = 4'b0011; // SLTIU
                    3'b100: alu_control = 4'b0100; // XORI
                    3'b101: alu_control = instruction_i[30] ? 4'b1001 : 4'b1000; // SRLI/SRAI
                    3'b110: alu_control = 4'b0110; // ORI
                    3'b111: alu_control = 4'b0111; // ANDI
                endcase
            end
            7'b0110011: begin // R-type (ADD, SUB, etc.)
                reg_write = 1'b1;
                case (funct3)
                    3'b000: alu_control = instruction_i[30] ? 4'b1011 : 4'b0000; // ADD/SUB
                    3'b001: alu_control = 4'b0001; // SLL
                    3'b010: alu_control = 4'b0010; // SLT
                    3'b011: alu_control = 4'b0011; // SLTU
                    3'b100: alu_control = 4'b0100; // XOR
                    3'b101: alu_control = instruction_i[30] ? 4'b1001 : 4'b1000; // SRL/SRA
                    3'b110: alu_control = 4'b0110; // OR
                    3'b111: alu_control = 4'b0111; // AND
                endcase
            end
            7'b0110111: begin // LUI
                alu_src = 1'b1;
                alu_control = 4'b1010; // Pass immediate
                reg_write = 1'b1;
            end
            7'b0010111: begin // AUIPC
                alu_src = 1'b1;
                alu_control = 4'b0000; // ADD
                reg_write = 1'b1;
            end
            7'b0100011: begin // S-type (SW, SB, SH)
                alu_src = 1'b1;
                alu_control = 4'b0000; // ADD
                mem_write = 1'b1;
                case (funct3)
                    3'b000: mem_write = 1'b1; // SB
                    3'b001: mem_write = 1'b1; // SH
                    3'b010: mem_write = 1'b1; // SW
                    default: mem_write = 1'b0; // Invalid
                endcase
            end
            7'b0000011: begin // I-type (LW, LB, LH, LBU, LHU)
                alu_src = 1'b1;
                alu_control = 4'b0000; // ADD
                mem_read = 1'b1;
                mem_to_reg = 1'b1;
                reg_write = 1'b1;
                case (funct3)
                    3'b000: begin mem_read = 1'b1; reg_write = 1'b1; end // LB
                    3'b001: begin mem_read = 1'b1; reg_write = 1'b1; end // LH
                    3'b010: begin mem_read = 1'b1; reg_write = 1'b1; end // LW
                    3'b100: begin mem_read = 1'b1; reg_write = 1'b1; end // LBU
                    3'b101: begin mem_read = 1'b1; reg_write = 1'b1; end // LHU
                    default: begin mem_read = 1'b0; reg_write = 1'b0; end // Invalid
                endcase
            end
            7'b1100011: begin // B-type (BEQ, BNE, BLT, BGE, BLTU, BGEU)
                branch = 1'b1;
                alu_control = 4'b1011; // SUB for comparison
                case (funct3)
                    3'b000: branch = 1'b1; // BEQ
                    3'b001: branch = 1'b1; // BNE
                    3'b100: branch = 1'b1; // BLT
                    3'b101: branch = 1'b1; // BGE
                    3'b110: branch = 1'b1; // BLTU
                    3'b111: branch = 1'b1; // BGEU
                    default: branch = 1'b0; // Invalid
                endcase
            end
            7'b1101111: begin // JAL
                jump = 1'b1;
                reg_write = 1'b1;
            end
            7'b1100111: begin // JALR
                jump = 1'b1;
                alu_src = 1'b1;
                alu_control = 4'b0000; // ADD
                reg_write = 1'b1;
            end
        endcase
    end
    
    // Hazard detection signals
    assign rs1_read_o = (opcode == 7'b0110011) || (opcode == 7'b0010011) || 
                       (opcode == 7'b0100011) || (opcode == 7'b0000011) || 
                       (opcode == 7'b1100011) || (opcode == 7'b1100111) || 
                       (opcode == 7'b0010111);
    assign rs2_read_o = (opcode == 7'b0110011) || (opcode == 7'b0100011) || 
                       (opcode == 7'b1100011);
    
    // Outputs
    assign reg_write_o = reg_write;
    assign mem_to_reg_o = mem_to_reg;
    assign mem_write_o = mem_write;
    assign mem_read_o = mem_read;
    assign alu_src_o = alu_src;
    assign alu_control_o = alu_control;
    assign branch_o = branch;
    assign jump_o = jump;
    assign pc_src_o = pc_src;
    assign pc_o = pc_i;
    assign pc_plus4_o = pc_plus4_i;
    assign immediate_o = immediate;
    assign reg_data1_o = reg_data1_i;
    assign reg_data2_o = reg_data2_i;
    assign rs1_addr_o = rs1;
    assign rs2_addr_o = rs2;
    assign rd_addr_o = rd;
    assign instruction_o = instruction_i;
    assign id_valid_o = id_valid_i & ~flush_i;

endmodule
