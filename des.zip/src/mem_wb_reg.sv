`timescale 1ns / 1ps

// MEM/WB Pipeline Register
module mem_wb_reg (
    input  logic        clk_i,
    input  logic        resetn_i,
    input  logic        stall_i,
    input  logic        flush_i,
    // Control signals from MEM
    input  logic        reg_write_i,
    input  logic        mem_to_reg_i,
    // Data from MEM
    input  logic [31:0] alu_result_i,
    input  logic [31:0] mem_data_i,
    input  logic [4:0]  rd_addr_i,
    input  logic [31:0] instruction_i,
    input  logic        mem_valid_i,
    // Outputs to WB stage
    output logic        reg_write_o,
    output logic        mem_to_reg_o,
    output logic [31:0] alu_result_o,
    output logic [31:0] mem_data_o,
    output logic [4:0]  rd_addr_o,
    output logic [31:0] instruction_o,
    output logic        mem_valid_o
);

    always_ff @(posedge clk_i or negedge resetn_i) begin
        if (!resetn_i || flush_i) begin
            reg_write_o <= 1'b0;
            mem_to_reg_o <= 1'b0;
            alu_result_o <= 32'h0;
            mem_data_o <= 32'h0;
            rd_addr_o <= 5'b0;
            instruction_o <= 32'h0;
            mem_valid_o <= 1'b0;
        end else if (!stall_i) begin
            reg_write_o <= reg_write_i;
            mem_to_reg_o <= mem_to_reg_i;
            alu_result_o <= alu_result_i;
            mem_data_o <= mem_data_i;
            rd_addr_o <= rd_addr_i;
            instruction_o <= instruction_i;
            mem_valid_o <= mem_valid_i;
        end
    end

endmodule
