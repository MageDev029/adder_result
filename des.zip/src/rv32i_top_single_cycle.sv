`timescale 1ns / 1ps

module rv32i_top (
    input  logic        clk_i,
    input  logic        resetn_i,
    output logic        illegal_inst_o,
    output logic [31:0] imem_addr_o,
    input  logic [31:0] imem_inst_i,
    output logic [31:0] mem_addr_o,
    output logic [31:0] mem_dat_o,
    input  logic [31:0] mem_dat_i,
    output logic        mem_write_o,
    output logic [3:0]  mem_wstrb_o,
    output logic        mem_read_o,
    input  logic        mem_ack_i
);

    // 5-stage pipelined processor implementation
    // Pipeline stage signals
    // IF stage outputs
    logic [31:0] if_pc, if_pc_plus4, if_instruction;
    logic        if_valid;
    
    // ID stage outputs
    logic        id_reg_write, id_mem_to_reg, id_mem_write, id_mem_read;
    logic        id_alu_src, id_branch, id_jump;
    logic [3:0]  id_alu_control;
    logic [31:0] id_pc, id_pc_plus4, id_immediate;
    logic [31:0] id_reg_data1, id_reg_data2;
    logic [4:0]  id_rs1_addr, id_rs2_addr, id_rd_addr;
    logic [31:0] id_instruction;
    logic        id_valid, id_rs1_read, id_rs2_read;
    
    // EX stage outputs
    logic        ex_reg_write, ex_mem_to_reg, ex_mem_write, ex_mem_read;
    logic [31:0] ex_alu_result, ex_reg_data2;
    logic [4:0]  ex_rd_addr;
    logic [31:0] ex_instruction;
    logic        ex_valid, ex_branch_taken;
    logic [31:0] ex_branch_target;
    logic        ex_pc_src;
    
    // MEM stage outputs
    logic        mem_reg_write, mem_mem_to_reg;
    logic [31:0] mem_alu_result, mem_mem_data;
    logic [4:0]  mem_rd_addr;
    logic [31:0] mem_instruction;
    logic        mem_valid;
    
    // WB stage outputs
    logic        wb_reg_write;
    logic [4:0]  wb_rd_addr;
    logic [31:0] wb_rd_data;
    
    // Hazard and forwarding signals
    logic        pc_stall, if_stall, id_stall, ex_stall;
    logic        if_flush, id_flush, ex_flush;
    logic [1:0]  forward_sel1, forward_sel2;
    logic [31:0] forward_data1, forward_data2;
    
    // Register file signals
    logic [31:0] reg_data1, reg_data2;
    
    // Branch logic
    logic branch_taken;
    logic [31:0] branch_target;
    
    // Branch decision
    always_comb begin
        branch_taken = 1'b0;
        case (instruction[6:0])
            7'b1100011: begin // B-type
                case (instruction[14:12])
                    3'b000: branch_taken = (reg_file[instruction[19:15]] == reg_file[instruction[24:20]]); // BEQ
                    3'b001: branch_taken = (reg_file[instruction[19:15]] != reg_file[instruction[24:20]]); // BNE
                    3'b100: branch_taken = ($signed(reg_file[instruction[19:15]]) < $signed(reg_file[instruction[24:20]])); // BLT
                    3'b101: branch_taken = ($signed(reg_file[instruction[19:15]]) >= $signed(reg_file[instruction[24:20]])); // BGE
                    3'b110: branch_taken = (reg_file[instruction[19:15]] < reg_file[instruction[24:20]]); // BLTU
                    3'b111: branch_taken = (reg_file[instruction[19:15]] >= reg_file[instruction[24:20]]); // BGEU
                    default: branch_taken = 1'b0;                                                                                           
                endcase
            end
            7'b1101111: branch_taken = 1'b1; // JAL
        endcase
    end
    
    // Branch target calculation
    always_comb begin
        case (instruction[6:0])
            7'b1100011: begin // B-type
                branch_target = pc + {{20{instruction[31]}}, instruction[7], instruction[30:25], instruction[11:8], 1'b0};
            end
            7'b1101111: begin // JAL
                branch_target = pc + {{12{instruction[31]}}, instruction[19:12], instruction[20], instruction[30:21], 1'b0};
            end
            default: branch_target = pc + 4;
        endcase
    end
    
    // PC advancement
    always_ff @(posedge clk_i or negedge resetn_i) begin
        if (!resetn_i) begin
            pc <= 32'h00000000;
        end else begin
            pc <= branch_taken ? branch_target : (pc + 32'd4);
        end
    end
    
    // Instruction fetch
    assign imem_addr_o = pc;
    assign instruction = imem_inst_i;
    
    // Immediate generation
    always_comb begin
        case (instruction[6:0])
            7'b0010011: immediate = {{20{instruction[31]}}, instruction[31:20]}; // I-type
            7'b0110111: immediate = {instruction[31:12], 12'b0}; // U-type
            7'b0010111: immediate = {instruction[31:12], 12'b0}; // U-type (AUIPC)
            default: immediate = 32'h0;
        endcase
    end
    
    // Control unit
    always_comb begin
        alu_src = 1'b0;
        alu_control = 4'b0000;
        reg_write = 1'b0;
        mem_write = 1'b0;
        mem_read = 1'b0;
        
        case (instruction[6:0])
            7'b0010011: begin // I-type (ADDI, etc.)
                alu_src = 1'b1;
                case (instruction[14:12])
                    3'b000: alu_control = 4'b0000; // ADDI
                    3'b001: alu_control = 4'b0001; // SLLI
                    3'b010: alu_control = 4'b0010; // SLTI
                    3'b011: alu_control = 4'b0011; // SLTIU
                    3'b100: alu_control = 4'b0100; // XORI
                    3'b101: alu_control = instruction[30] ? 4'b1001 : 4'b1000; // SRLI/SRAI
                    3'b110: alu_control = 4'b0110; // ORI
                    3'b111: alu_control = 4'b0111; // ANDI
                    default: alu_control = 4'b0000; // Default to ADD
                endcase
                reg_write = 1'b1;
            end
            7'b0110011: begin // R-type (ADD, SUB, etc.)
                case (instruction[14:12])
                    3'b000: alu_control = instruction[30] ? 4'b0001 : 4'b0000; // ADD/SUB
                    3'b010: alu_control = 4'b0010; // SLT
                    3'b011: alu_control = 4'b0011; // SLTU
                    3'b100: alu_control = 4'b0100; // XOR
                    3'b110: alu_control = 4'b0110; // OR
                    3'b111: alu_control = 4'b0111; // AND
                    default: alu_control = 4'b0000; // Default to ADD
                endcase
                reg_write = 1'b1;
            end
            7'b0110111: begin // LUI
                alu_src = 1'b1;
                alu_control = 4'b1010; // Pass immediate
                reg_write = 1'b1;
            end
            7'b0010111: begin // AUIPC
                alu_src = 1'b1;
                alu_control = 4'b0000; // ADD
                reg_write = 1'b1;
            end
            7'b0100011: begin // S-type (SW, etc.)
                alu_src = 1'b1;
                alu_control = 4'b0000; // ADD
                mem_write = 1'b1;
            end
            7'b0000011: begin // I-type (LW, etc.)
                alu_src = 1'b1;
                alu_control = 4'b0000; // ADD
                mem_read = 1'b1;
                reg_write = 1'b1;
            end
            7'b1101111: begin // JAL
                reg_write = 1'b1; // Write return address
            end
        endcase
    end
    
    // ALU
    always_comb begin
        case (alu_control)
            4'b0000: alu_result = reg_file[instruction[19:15]] + (alu_src ? immediate : reg_file[instruction[24:20]]); // ADD
            4'b0001: alu_result = reg_file[instruction[19:15]] << (alu_src ? immediate[4:0] : reg_file[instruction[24:20]][4:0]); // SLL
            4'b0010: alu_result = ($signed(reg_file[instruction[19:15]]) < $signed(alu_src ? immediate : reg_file[instruction[24:20]])) ? 32'h1 : 32'h0; // SLT
            4'b0011: alu_result = (reg_file[instruction[19:15]] < (alu_src ? immediate : reg_file[instruction[24:20]])) ? 32'h1 : 32'h0; // SLTU
            4'b0100: alu_result = reg_file[instruction[19:15]] ^ (alu_src ? immediate : reg_file[instruction[24:20]]); // XOR
            4'b0110: alu_result = reg_file[instruction[19:15]] | (alu_src ? immediate : reg_file[instruction[24:20]]); // OR
            4'b0111: alu_result = reg_file[instruction[19:15]] & (alu_src ? immediate : reg_file[instruction[24:20]]); // AND
            4'b1000: alu_result = reg_file[instruction[19:15]] >> (alu_src ? immediate[4:0] : reg_file[instruction[24:20]][4:0]); // SRL
            4'b1001: alu_result = $signed(reg_file[instruction[19:15]]) >>> (alu_src ? immediate[4:0] : reg_file[instruction[24:20]][4:0]); // SRA
            4'b1010: alu_result = immediate; // Pass immediate
            default: alu_result = 32'h0;
        endcase
    end
    
    // Register file
    always_ff @(posedge clk_i) begin
        if (reg_write && instruction[11:7] != 5'b0) begin
            if (mem_read) begin
                reg_file[instruction[11:7]] <= mem_dat_i;
            end else if (instruction[6:0] == 7'b1101111) begin
                reg_file[instruction[11:7]] <= pc + 4; // JAL return address
            end else begin
                reg_file[instruction[11:7]] <= alu_result;
            end
        end
    end
    
    // Initialize register file
    integer i;
    initial begin
        for (i = 0; i < 32; i = i + 1) begin
            reg_file[i] = 32'h0;
        end
    end
    
    // Memory interface
    assign mem_addr_o = alu_result;
    assign mem_dat_o = reg_file[instruction[24:20]];
    assign mem_write_o = mem_write;
    assign mem_wstrb_o = mem_write ? 4'b1111 : 4'b0000;
    assign mem_read_o = mem_read;
    
    // Outputs
    assign illegal_inst_o = 1'b0;
    
    // Tracer Integration
    `ifdef tracer
    logic [31:0] rvfi_insn;
    logic [4:0]  rvfi_rs1_addr, rvfi_rs2_addr, rvfi_rd_addr;
    logic [31:0] rvfi_rs1_rdata, rvfi_rs2_rdata, rvfi_rd_wdata;
    logic [31:0] rvfi_pc_rdata, rvfi_pc_wdata;
    logic [31:0] rvfi_mem_addr, rvfi_mem_wdata, rvfi_mem_rdata;
    logic [3:0]  rvfi_mem_rmask, rvfi_mem_wmask;
    logic        rvfi_valid;
    
    assign rvfi_insn = instruction;
    assign rvfi_rs1_addr = instruction[19:15];
    assign rvfi_rs2_addr = instruction[24:20];
    assign rvfi_rd_addr = instruction[11:7];
    assign rvfi_rs1_rdata = reg_file[instruction[19:15]];
    assign rvfi_rs2_rdata = reg_file[instruction[24:20]];
    assign rvfi_rd_wdata = reg_write ? (mem_read ? mem_dat_i : alu_result) : 32'h0;
    assign rvfi_pc_rdata = pc;
    assign rvfi_pc_wdata = pc + 4;
    assign rvfi_mem_addr = mem_addr;
    assign rvfi_mem_wdata = mem_data;
    assign rvfi_mem_rdata = mem_dat_i;
    assign rvfi_mem_rmask = mem_read ? 4'b1111 : 4'b0000;
    assign rvfi_mem_wmask = mem_write ? 4'b1111 : 4'b0000;
    assign rvfi_valid = 1'b1;
    
    tracer tracer_inst (
        .clk_i(clk_i),
        .rst_ni(resetn_i),
        .hart_id_i(1),
        .rvfi_insn_t(rvfi_insn),
        .rvfi_rs1_addr_t(rvfi_rs1_addr),
        .rvfi_rs2_addr_t(rvfi_rs2_addr),
        .rvfi_rs3_addr_t(),
        .rvfi_rs3_rdata_t(),
        .rvfi_mem_rmask(rvfi_mem_rmask),
        .rvfi_mem_wmask(rvfi_mem_wmask),
        .rvfi_rs1_rdata_t(rvfi_rs1_rdata),
        .rvfi_rs2_rdata_t(rvfi_rs2_rdata),
        .rvfi_rd_addr_t(rvfi_rd_addr),
        .rvfi_rd_wdata_t(rvfi_rd_wdata),
        .rvfi_pc_rdata_t(rvfi_pc_rdata),
        .rvfi_pc_wdata_t(rvfi_pc_wdata),
        .rvfi_mem_addr(rvfi_mem_addr),
        .rvfi_mem_wdata(rvfi_mem_wdata),
        .rvfi_mem_rdata(rvfi_mem_rdata),
        .rvfi_valid(rvfi_valid)
    );
    `endif

endmodule