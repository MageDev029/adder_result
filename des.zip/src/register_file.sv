`timescale 1ns / 1ps

module register_file (
    input  logic        clk_i,
    input  logic        resetn_i,
    // Read ports
    input  logic [4:0]  rs1_addr_i,
    input  logic [4:0]  rs2_addr_i,
    output logic [31:0] rs1_data_o,
    output logic [31:0] rs2_data_o,
    // Write port
    input  logic        reg_write_i,
    input  logic [4:0]  rd_addr_i,
    input  logic [31:0] rd_data_i
);

    logic [31:0] reg_file [0:31];
    
    // Read operations (combinational)
    assign rs1_data_o = (rs1_addr_i == 5'b0) ? 32'h0 : reg_file[rs1_addr_i];
    assign rs2_data_o = (rs2_addr_i == 5'b0) ? 32'h0 : reg_file[rs2_addr_i];
    
    // Write operation (sequential)
    always_ff @(posedge clk_i or negedge resetn_i) begin
        if (!resetn_i) begin
            // Initialize all registers to zero
            for (int i = 0; i < 32; i++) begin
                reg_file[i] <= 32'h0;
            end
        end else if (reg_write_i && rd_addr_i != 5'b0) begin
            reg_file[rd_addr_i] <= rd_data_i;
        end
    end

endmodule
