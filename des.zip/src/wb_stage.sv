`timescale 1ns / 1ps

module wb_stage (
    input  logic        clk_i,
    input  logic        resetn_i,
    // Control signals from MEM
    input  logic        reg_write_i,
    input  logic        mem_to_reg_i,
    // Data from MEM
    input  logic [31:0] alu_result_i,
    input  logic [31:0] mem_data_i,
    input  logic [4:0]  rd_addr_i,
    input  logic [31:0] instruction_i,
    input  logic        wb_valid_i,
    // Register file interface
    output logic        reg_write_o,
    output logic [4:0]  rd_addr_o,
    output logic [31:0] rd_data_o
);

    logic [31:0] write_data;
    logic [31:0] load_data;
    
    // Load data processing with sign extension
    always_comb begin
        if (mem_to_reg_i) begin
            case (instruction_i[14:12]) // funct3
                3'b000: begin // LB - load byte (signed)
                    case (alu_result_i[1:0])
                        2'b00: load_data = {{24{mem_data_i[7]}}, mem_data_i[7:0]};
                        2'b01: load_data = {{24{mem_data_i[15]}}, mem_data_i[15:8]};
                        2'b10: load_data = {{24{mem_data_i[23]}}, mem_data_i[23:16]};
                        2'b11: load_data = {{24{mem_data_i[31]}}, mem_data_i[31:24]};
                    endcase
                end
                3'b001: begin // LH - load halfword (signed)
                    case (alu_result_i[1])
                        1'b0: load_data = {{16{mem_data_i[15]}}, mem_data_i[15:0]};
                        1'b1: load_data = {{16{mem_data_i[31]}}, mem_data_i[31:16]};
                    endcase
                end
                3'b010: begin // LW - load word
                    load_data = mem_data_i;
                end
                3'b100: begin // LBU - load byte (unsigned)
                    case (alu_result_i[1:0])
                        2'b00: load_data = {24'b0, mem_data_i[7:0]};
                        2'b01: load_data = {24'b0, mem_data_i[15:8]};
                        2'b10: load_data = {24'b0, mem_data_i[23:16]};
                        2'b11: load_data = {24'b0, mem_data_i[31:24]};
                    endcase
                end
                3'b101: begin // LHU - load halfword (unsigned)
                    case (alu_result_i[1])
                        1'b0: load_data = {16'b0, mem_data_i[15:0]};
                        1'b1: load_data = {16'b0, mem_data_i[31:16]};
                    endcase
                end
                default: load_data = mem_data_i;
            endcase
        end else begin
            load_data = mem_data_i;
        end
    end
    
    // Write data selection
    assign write_data = mem_to_reg_i ? load_data : alu_result_i;
    
    // Outputs
    assign reg_write_o = reg_write_i;
    assign rd_addr_o = rd_addr_i;
    assign rd_data_o = write_data;

endmodule
