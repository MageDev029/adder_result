`timescale 1ns / 1ps

// ID/EX Pipeline Register
module id_ex_reg (
    input  logic        clk_i,
    input  logic        resetn_i,
    input  logic        stall_i,
    input  logic        flush_i,
    // Control signals from ID
    input  logic        reg_write_i,
    input  logic        mem_to_reg_i,
    input  logic        mem_write_i,
    input  logic        mem_read_i,
    input  logic        alu_src_i,
    input  logic [3:0]  alu_control_i,
    input  logic        branch_i,
    input  logic        jump_i,
    // Data from ID
    input  logic [31:0] pc_i,
    input  logic [31:0] pc_plus4_i,
    input  logic [31:0] immediate_i,
    input  logic [31:0] reg_data1_i,
    input  logic [31:0] reg_data2_i,
    input  logic [4:0]  rs1_addr_i,
    input  logic [4:0]  rs2_addr_i,
    input  logic [4:0]  rd_addr_i,
    input  logic [31:0] instruction_i,
    input  logic        id_valid_i,
    // Outputs to EX stage
    output logic        reg_write_o,
    output logic        mem_to_reg_o,
    output logic        mem_write_o,
    output logic        mem_read_o,
    output logic        alu_src_o,
    output logic [3:0]  alu_control_o,
    output logic        branch_o,
    output logic        jump_o,
    output logic [31:0] pc_o,
    output logic [31:0] pc_plus4_o,
    output logic [31:0] immediate_o,
    output logic [31:0] reg_data1_o,
    output logic [31:0] reg_data2_o,
    output logic [4:0]  rs1_addr_o,
    output logic [4:0]  rs2_addr_o,
    output logic [4:0]  rd_addr_o,
    output logic [31:0] instruction_o,
    output logic        id_valid_o
);

    always_ff @(posedge clk_i or negedge resetn_i) begin
        if (!resetn_i || flush_i) begin
            reg_write_o <= 1'b0;
            mem_to_reg_o <= 1'b0;
            mem_write_o <= 1'b0;
            mem_read_o <= 1'b0;
            alu_src_o <= 1'b0;
            alu_control_o <= 4'b0;
            branch_o <= 1'b0;
            jump_o <= 1'b0;
            pc_o <= 32'h0;
            pc_plus4_o <= 32'h0;
            immediate_o <= 32'h0;
            reg_data1_o <= 32'h0;
            reg_data2_o <= 32'h0;
            rs1_addr_o <= 5'b0;
            rs2_addr_o <= 5'b0;
            rd_addr_o <= 5'b0;
            instruction_o <= 32'h0;
            id_valid_o <= 1'b0;
        end else if (!stall_i) begin
            reg_write_o <= reg_write_i;
            mem_to_reg_o <= mem_to_reg_i;
            mem_write_o <= mem_write_i;
            mem_read_o <= mem_read_i;
            alu_src_o <= alu_src_i;
            alu_control_o <= alu_control_i;
            branch_o <= branch_i;
            jump_o <= jump_i;
            pc_o <= pc_i;
            pc_plus4_o <= pc_plus4_i;
            immediate_o <= immediate_i;
            reg_data1_o <= reg_data1_i;
            reg_data2_o <= reg_data2_i;
            rs1_addr_o <= rs1_addr_i;
            rs2_addr_o <= rs2_addr_i;
            rd_addr_o <= rd_addr_i;
            instruction_o <= instruction_i;
            id_valid_o <= id_valid_i;
        end
    end

endmodule
