`timescale 1ns / 1ps

module hazard_unit (
    // ID stage inputs
    input  logic [4:0]  id_rs1_addr_i,
    input  logic [4:0]  id_rs2_addr_i,
    input  logic        id_rs1_read_i,
    input  logic        id_rs2_read_i,
    // EX stage inputs
    input  logic [4:0]  ex_rd_addr_i,
    input  logic        ex_reg_write_i,
    input  logic        ex_mem_read_i,
    // MEM stage inputs
    input  logic [4:0]  mem_rd_addr_i,
    input  logic        mem_reg_write_i,
    input  logic        mem_mem_read_i,
    // WB stage inputs
    input  logic [4:0]  wb_rd_addr_i,
    input  logic        wb_reg_write_i,
    // Branch inputs
    input  logic        branch_taken_i,
    // Outputs
    output logic        pc_stall_o,
    output logic        if_stall_o,
    output logic        id_stall_o,
    output logic        ex_stall_o,
    output logic        if_flush_o,
    output logic        id_flush_o,
    output logic        ex_flush_o
);

    logic load_use_hazard;
    logic branch_hazard;
    
    // Load-use hazard detection
    assign load_use_hazard = ex_mem_read_i && 
                            ((id_rs1_read_i && (id_rs1_addr_i == ex_rd_addr_i)) ||
                             (id_rs2_read_i && (id_rs2_addr_i == ex_rd_addr_i)));
    
    // Branch hazard detection
    assign branch_hazard = branch_taken_i;
    
    // Stall signals
    assign pc_stall_o = load_use_hazard;
    assign if_stall_o = load_use_hazard;
    assign id_stall_o = load_use_hazard;
    assign ex_stall_o = 1'b0; // EX stage never stalls
    
    // Flush signals
    assign if_flush_o = branch_hazard;
    assign id_flush_o = branch_hazard;
    assign ex_flush_o = branch_hazard;

endmodule
