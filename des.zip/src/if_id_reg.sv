`timescale 1ns / 1ps

// IF/ID Pipeline Register
module if_id_reg (
    input  logic        clk_i,
    input  logic        resetn_i,
    input  logic        stall_i,
    input  logic        flush_i,
    // Inputs from IF stage
    input  logic [31:0] pc_i,
    input  logic [31:0] pc_plus4_i,
    input  logic [31:0] instruction_i,
    input  logic        if_valid_i,
    // Outputs to ID stage
    output logic [31:0] pc_o,
    output logic [31:0] pc_plus4_o,
    output logic [31:0] instruction_o,
    output logic        if_valid_o
);

    always_ff @(posedge clk_i or negedge resetn_i) begin
        if (!resetn_i || flush_i) begin
            pc_o <= 32'h0;
            pc_plus4_o <= 32'h0;
            instruction_o <= 32'h0;
            if_valid_o <= 1'b0;
        end else if (!stall_i) begin
            pc_o <= pc_i;
            pc_plus4_o <= pc_plus4_i;
            instruction_o <= instruction_i;
            if_valid_o <= if_valid_i;
        end
    end

endmodule
