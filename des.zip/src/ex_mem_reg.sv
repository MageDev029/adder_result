`timescale 1ns / 1ps

// EX/MEM Pipeline Register
module ex_mem_reg (
    input  logic        clk_i,
    input  logic        resetn_i,
    input  logic        stall_i,
    input  logic        flush_i,
    // Control signals from EX
    input  logic        reg_write_i,
    input  logic        mem_to_reg_i,
    input  logic        mem_write_i,
    input  logic        mem_read_i,
    // Data from EX
    input  logic [31:0] alu_result_i,
    input  logic [31:0] reg_data2_i,
    input  logic [4:0]  rd_addr_i,
    input  logic [31:0] instruction_i,
    input  logic        ex_valid_i,
    // Outputs to MEM stage
    output logic        reg_write_o,
    output logic        mem_to_reg_o,
    output logic        mem_write_o,
    output logic        mem_read_o,
    output logic [31:0] alu_result_o,
    output logic [31:0] reg_data2_o,
    output logic [4:0]  rd_addr_o,
    output logic [31:0] instruction_o,
    output logic        ex_valid_o
);

    always_ff @(posedge clk_i or negedge resetn_i) begin
        if (!resetn_i || flush_i) begin
            reg_write_o <= 1'b0;
            mem_to_reg_o <= 1'b0;
            mem_write_o <= 1'b0;
            mem_read_o <= 1'b0;
            alu_result_o <= 32'h0;
            reg_data2_o <= 32'h0;
            rd_addr_o <= 5'b0;
            instruction_o <= 32'h0;
            ex_valid_o <= 1'b0;
        end else if (!stall_i) begin
            reg_write_o <= reg_write_i;
            mem_to_reg_o <= mem_to_reg_i;
            mem_write_o <= mem_write_i;
            mem_read_o <= mem_read_i;
            alu_result_o <= alu_result_i;
            reg_data2_o <= reg_data2_i;
            rd_addr_o <= rd_addr_i;
            instruction_o <= instruction_i;
            ex_valid_o <= ex_valid_i;
        end
    end

endmodule
