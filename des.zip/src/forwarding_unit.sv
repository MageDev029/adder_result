`timescale 1ns / 1ps

module forwarding_unit (
    // EX stage inputs
    input  logic [4:0]  ex_rs1_addr_i,
    input  logic [4:0]  ex_rs2_addr_i,
    // MEM stage inputs
    input  logic [4:0]  mem_rd_addr_i,
    input  logic        mem_reg_write_i,
    // WB stage inputs
    input  logic [4:0]  wb_rd_addr_i,
    input  logic        wb_reg_write_i,
    // Outputs
    output logic [1:0]  forward_sel1_o,
    output logic [1:0]  forward_sel2_o
);

    // Forwarding for rs1
    always_comb begin
        if (mem_reg_write_i && (mem_rd_addr_i != 5'b0) && (mem_rd_addr_i == ex_rs1_addr_i)) begin
            forward_sel1_o = 2'b01; // Forward from MEM stage
        end else if (wb_reg_write_i && (wb_rd_addr_i != 5'b0) && (wb_rd_addr_i == ex_rs1_addr_i) && 
                    !(mem_reg_write_i && (mem_rd_addr_i != 5'b0) && (mem_rd_addr_i == ex_rs1_addr_i))) begin
            forward_sel1_o = 2'b10; // Forward from WB stage
        end else begin
            forward_sel1_o = 2'b00; // No forwarding
        end
    end
    
    // Forwarding for rs2
    always_comb begin
        if (mem_reg_write_i && (mem_rd_addr_i != 5'b0) && (mem_rd_addr_i == ex_rs2_addr_i)) begin
            forward_sel2_o = 2'b01; // Forward from MEM stage
        end else if (wb_reg_write_i && (wb_rd_addr_i != 5'b0) && (wb_rd_addr_i == ex_rs2_addr_i) && 
                    !(mem_reg_write_i && (mem_rd_addr_i != 5'b0) && (mem_rd_addr_i == ex_rs2_addr_i))) begin
            forward_sel2_o = 2'b10; // Forward from WB stage
        end else begin
            forward_sel2_o = 2'b00; // No forwarding
        end
    end

endmodule
