#!/usr/bin/env python3
"""
Comprehensive Pipeline Verification Script
Verifies the RISC-V RV32I 5-stage pipeline implementation
"""

import os
import re
import sys

def read_file(filepath):
    """Read file content"""
    try:
        with open(filepath, 'r') as f:
            return f.read()
    except FileNotFoundError:
        return None

def check_instruction_coverage():
    """Check if all instruction types are covered"""
    print("=== Checking Instruction Coverage ===")
    
    id_stage_content = read_file('src/id_stage.sv')
    if not id_stage_content:
        print("❌ Cannot read id_stage.sv")
        return False
    
    # Check for all RISC-V RV32I instruction opcodes
    opcodes = {
        '7\'b0010011': 'I-type (ADDI, etc.)',
        '7\'b0000011': 'I-type (LW, LB, LH, LBU, LHU)',
        '7\'b0100011': 'S-type (SW, SB, SH)',
        '7\'b0110011': 'R-type (ADD, SUB, etc.)',
        '7\'b1100011': 'B-type (BEQ, BNE, etc.)',
        '7\'b0110111': 'U-type (LUI)',
        '7\'b0010111': 'U-type (AUIPC)',
        '7\'b1101111': 'J-type (JAL)',
        '7\'b1100111': 'I-type (JALR)'
    }
    
    missing_opcodes = []
    for opcode, description in opcodes.items():
        if opcode not in id_stage_content:
            missing_opcodes.append(f"{opcode} ({description})")
    
    if missing_opcodes:
        print("❌ Missing instruction opcodes:")
        for opcode in missing_opcodes:
            print(f"   - {opcode}")
        return False
    else:
        print("✅ All instruction opcodes are covered")
        return True

def check_immediate_generation():
    """Check immediate generation for all instruction types"""
    print("\n=== Checking Immediate Generation ===")
    
    id_stage_content = read_file('src/id_stage.sv')
    if not id_stage_content:
        print("❌ Cannot read id_stage.sv")
        return False
    
    # Check if load instructions are included in immediate generation
    if '7\'b0000011' in id_stage_content and 'immediate = {{20{instruction_i[31]}}, instruction_i[31:20]};' in id_stage_content:
        print("✅ Load instructions included in immediate generation")
    else:
        print("❌ Load instructions missing from immediate generation")
        return False
    
    # Check if JALR is included in immediate generation
    if '7\'b1100111' in id_stage_content and 'immediate = {{20{instruction_i[31]}}, instruction_i[31:20]};' in id_stage_content:
        print("✅ JALR included in immediate generation")
    else:
        print("❌ JALR missing from immediate generation")
        return False
    
    return True

def check_alu_operations():
    """Check ALU operations"""
    print("\n=== Checking ALU Operations ===")
    
    ex_stage_content = read_file('src/ex_stage.sv')
    if not ex_stage_content:
        print("❌ Cannot read ex_stage.sv")
        return False
    
    # Check for SUB operation
    if '4\'b1011: alu_result = alu_src1 - alu_src2; // SUB' in ex_stage_content:
        print("✅ SUB operation implemented")
    else:
        print("❌ SUB operation missing")
        return False
    
    # Check for JAL/JALR PC+4 handling
    if 'pc_plus4_i' in ex_stage_content and '7\'b1101111' in ex_stage_content and '7\'b1100111' in ex_stage_content:
        print("✅ JAL/JALR PC+4 handling implemented")
    else:
        print("❌ JAL/JALR PC+4 handling missing")
        return False
    
    # Check for AUIPC PC handling
    if '7\'b0010111' in ex_stage_content and 'pc_i' in ex_stage_content:
        print("✅ AUIPC PC handling implemented")
    else:
        print("❌ AUIPC PC handling missing")
        return False
    
    return True

def check_memory_interface():
    """Check memory interface"""
    print("\n=== Checking Memory Interface ===")
    
    mem_stage_content = read_file('src/mem_stage.sv')
    if not mem_stage_content:
        print("❌ Cannot read mem_stage.sv")
        return False
    
    # Check for write strobe generation
    if 'mem_wstrb_o' in mem_stage_content and '3\'b000' in mem_stage_content and '3\'b001' in mem_stage_content and '3\'b010' in mem_stage_content:
        print("✅ Write strobe generation implemented")
    else:
        print("❌ Write strobe generation missing")
        return False
    
    wb_stage_content = read_file('src/wb_stage.sv')
    if not wb_stage_content:
        print("❌ Cannot read wb_stage.sv")
        return False
    
    # Check for load data processing
    if 'load_data' in wb_stage_content and '3\'b000' in wb_stage_content and '3\'b001' in wb_stage_content:
        print("✅ Load data processing implemented")
    else:
        print("❌ Load data processing missing")
        return False
    
    return True

def check_pipeline_connections():
    """Check pipeline connections"""
    print("\n=== Checking Pipeline Connections ===")
    
    top_content = read_file('src/rv32i_top.sv')
    if not top_content:
        print("❌ Cannot read rv32i_top.sv")
        return False
    
    # Check for all pipeline stages
    stages = ['if_stage_inst', 'id_stage_inst', 'ex_stage_inst', 'mem_stage_inst', 'wb_stage_inst']
    for stage in stages:
        if stage in top_content:
            print(f"✅ {stage} connected")
        else:
            print(f"❌ {stage} missing")
            return False
    
    # Check for all pipeline registers
    registers = ['if_id_reg_inst', 'id_ex_reg_inst', 'ex_mem_reg_inst', 'mem_wb_reg_inst']
    for reg in registers:
        if reg in top_content:
            print(f"✅ {reg} connected")
        else:
            print(f"❌ {reg} missing")
            return False
    
    # Check for supporting modules
    modules = ['reg_file_inst', 'hazard_unit_inst', 'forwarding_unit_inst']
    for module in modules:
        if module in top_content:
            print(f"✅ {module} connected")
        else:
            print(f"❌ {module} missing")
            return False
    
    return True

def check_hazard_handling():
    """Check hazard handling"""
    print("\n=== Checking Hazard Handling ===")
    
    hazard_content = read_file('src/hazard_unit.sv')
    if not hazard_content:
        print("❌ Cannot read hazard_unit.sv")
        return False
    
    # Check for load-use hazard detection
    if 'load_use_hazard' in hazard_content and 'ex_mem_read_i' in hazard_content:
        print("✅ Load-use hazard detection implemented")
    else:
        print("❌ Load-use hazard detection missing")
        return False
    
    # Check for branch hazard detection
    if 'branch_hazard' in hazard_content and 'branch_taken_i' in hazard_content:
        print("✅ Branch hazard detection implemented")
    else:
        print("❌ Branch hazard detection missing")
        return False
    
    forwarding_content = read_file('src/forwarding_unit.sv')
    if not forwarding_content:
        print("❌ Cannot read forwarding_unit.sv")
        return False
    
    # Check for forwarding
    if 'forward_sel1_o' in forwarding_content and 'forward_sel2_o' in forwarding_content:
        print("✅ Forwarding unit implemented")
    else:
        print("❌ Forwarding unit missing")
        return False
    
    return True

def check_file_structure():
    """Check file structure"""
    print("\n=== Checking File Structure ===")
    
    required_files = [
        'src/rv32i_top.sv',
        'src/if_stage.sv',
        'src/id_stage.sv',
        'src/ex_stage.sv',
        'src/mem_stage.sv',
        'src/wb_stage.sv',
        'src/if_id_reg.sv',
        'src/id_ex_reg.sv',
        'src/ex_mem_reg.sv',
        'src/mem_wb_reg.sv',
        'src/register_file.sv',
        'src/hazard_unit.sv',
        'src/forwarding_unit.sv'
    ]
    
    missing_files = []
    for file in required_files:
        if not os.path.exists(file):
            missing_files.append(file)
    
    if missing_files:
        print("❌ Missing files:")
        for file in missing_files:
            print(f"   - {file}")
        return False
    else:
        print("✅ All required files present")
        return True

def main():
    """Main verification function"""
    print("🔍 COMPREHENSIVE PIPELINE VERIFICATION")
    print("=" * 50)
    
    checks = [
        check_file_structure,
        check_instruction_coverage,
        check_immediate_generation,
        check_alu_operations,
        check_memory_interface,
        check_pipeline_connections,
        check_hazard_handling
    ]
    
    passed_checks = 0
    total_checks = len(checks)
    
    for check in checks:
        if check():
            passed_checks += 1
        else:
            print("❌ Check failed!")
    
    print("\n" + "=" * 50)
    print("📊 VERIFICATION RESULTS")
    print("=" * 50)
    print(f"Passed: {passed_checks}/{total_checks}")
    print(f"Success rate: {(passed_checks/total_checks)*100:.1f}%")
    
    if passed_checks == total_checks:
        print("\n🎉 ALL CHECKS PASSED! 🎉")
        print("The pipeline implementation looks correct!")
        print("\nKey fixes verified:")
        print("✅ Load instruction immediate generation")
        print("✅ JAL/JALR return address handling")
        print("✅ AUIPC PC addition")
        print("✅ SUB operation in ALU")
        print("✅ Memory interface with proper write strobes")
        print("✅ Load data sign extension")
        print("✅ Pipeline hazard handling")
        print("✅ Data forwarding")
        return 0
    else:
        print(f"\n❌ {total_checks - passed_checks} CHECKS FAILED")
        print("Need to fix the issues above")
        return 1

if __name__ == "__main__":
    sys.exit(main())
