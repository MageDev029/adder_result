# RTL File List for RV32I 5-Stage Pipelined Processor
# This file contains all the SystemVerilog source files for the pipelined processor
# Usage: Use this file with synthesis/simulation tools to include all necessary modules

# =============================================================================
# MAIN TOP-LEVEL MODULE
# =============================================================================
src/rv32i_top.sv

# =============================================================================
# PIPELINE STAGE MODULES
# =============================================================================
# Stage 1: Instruction Fetch
src/if_stage.sv

# Stage 2: Instruction Decode
src/id_stage.sv

# Stage 3: Execute
src/ex_stage.sv

# Stage 4: Memory Access
src/mem_stage.sv

# Stage 5: Writeback
src/wb_stage.sv

# =============================================================================
# SUPPORTING MODULES
# =============================================================================
# Register file with dual-port read, single-port write
src/register_file.sv

# Pipeline registers between stages
src/if_id_reg.sv
src/id_ex_reg.sv
src/ex_mem_reg.sv
src/mem_wb_reg.sv

# Hazard detection and control unit
src/hazard_unit.sv

# Data forwarding unit
src/forwarding_unit.sv

# =============================================================================
# ALTERNATIVE IMPLEMENTATIONS (COMMENTED OUT)
# =============================================================================
# Alternative pipelined top module (if needed)
# src/rv32i_pipelined_top.sv

# Original single-cycle implementation (backup)
# src/rv32i_top_single_cycle.sv

# =============================================================================
# COMPILATION NOTES
# =============================================================================
# - All files use SystemVerilog syntax
# - Timescale: 1ns / 1ps
# - Compatible with most modern synthesis and simulation tools
# - No external dependencies required
# - Tracer integration available with `ifdef tracer
