`timescale 1ns / 1ps

module if_stage (
    input  logic        clk_i,
    input  logic        resetn_i,
    input  logic        pc_src_i,        // Branch taken signal
    input  logic [31:0] pc_branch_i,     // Branch target address
    input  logic        stall_i,         // Pipeline stall signal
    input  logic        flush_i,         // Pipeline flush signal
    output logic [31:0] pc_o,            // Current PC
    output logic [31:0] pc_plus4_o,      // PC + 4
    output logic [31:0] instruction_o,   // Fetched instruction
    output logic        if_valid_o,      // IF stage valid
    // Memory interface
    output logic [31:0] imem_addr_o,
    input  logic [31:0] imem_inst_i
);

    logic [31:0] pc;
    logic [31:0] pc_next;
    logic [31:0] pc_plus4;
    
    // PC calculation
    assign pc_plus4 = pc + 32'd4;
    assign pc_next = pc_src_i ? pc_branch_i : pc_plus4;
    
    // PC register
    always_ff @(posedge clk_i or negedge resetn_i) begin
        if (!resetn_i) begin
            pc <= 32'h00000000;
        end else if (!stall_i) begin
            pc <= pc_next;
        end
    end
    
    // Outputs
    assign pc_o = pc;
    assign pc_plus4_o = pc_plus4;
    assign instruction_o = imem_inst_i;
    assign if_valid_o = 1'b1; // IF stage is always valid when not stalled
    assign imem_addr_o = pc;

endmodule
