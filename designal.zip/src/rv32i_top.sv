`timescale 1ns / 1ps

module rv32i_top (
    input  logic        clk_i,
    input  logic        resetn_i,
    output logic        illegal_inst_o,
    output logic [31:0] imem_addr_o,
    input  logic [31:0] imem_inst_i,
    output logic [31:0] mem_addr_o,
    output logic [31:0] mem_dat_o,
    input  logic [31:0] mem_dat_i,
    output logic        mem_write_o,
    output logic [3:0]  mem_wstrb_o,
    output logic        mem_read_o,
    input  logic        mem_ack_i
);

    // 5-stage pipelined processor implementation
    // Pipeline stage signals
    // IF stage outputs
    logic [31:0] if_pc, if_pc_plus4, if_instruction;
    logic        if_valid;
    
    // ID stage outputs
    logic        id_reg_write, id_mem_to_reg, id_mem_write, id_mem_read;
    logic        id_alu_src, id_branch, id_jump;
    logic [3:0]  id_alu_control;
    logic [31:0] id_pc, id_pc_plus4, id_immediate;
    logic [31:0] id_reg_data1, id_reg_data2;
    logic [4:0]  id_rs1_addr, id_rs2_addr, id_rd_addr;
    logic [31:0] id_instruction;
    logic        id_valid, id_rs1_read, id_rs2_read;
    
    // ID/EX register outputs
    logic        id_ex_reg_write, id_ex_mem_to_reg, id_ex_mem_write, id_ex_mem_read;
    logic        id_ex_alu_src;
    logic [3:0]  id_ex_alu_control;
    logic        id_ex_branch, id_ex_jump;
    logic [31:0] id_ex_pc, id_ex_pc_plus4, id_ex_immediate;
    logic [31:0] id_ex_reg_data1, id_ex_reg_data2;
    logic [4:0]  id_ex_rs1_addr, id_ex_rs2_addr, id_ex_rd_addr;
    logic [31:0] id_ex_instruction;
    logic        id_ex_valid;
    
    // EX stage outputs
    logic        ex_reg_write, ex_mem_to_reg, ex_mem_write, ex_mem_read;
    logic [31:0] ex_alu_result, ex_reg_data2;
    logic [4:0]  ex_rd_addr;
    logic [31:0] ex_instruction;
    logic        ex_valid, ex_branch_taken;
    logic [31:0] ex_branch_target;
    logic        ex_pc_src;
    
    // MEM stage outputs
    logic        mem_reg_write, mem_mem_to_reg;
    logic [31:0] mem_alu_result, mem_mem_data;
    logic [4:0]  mem_rd_addr;
    logic [31:0] mem_instruction;
    logic        mem_valid;
    
    // WB stage outputs
    logic        wb_reg_write;
    logic [4:0]  wb_rd_addr;
    logic [31:0] wb_rd_data;
    
    // Hazard and forwarding signals
    logic        pc_stall, if_stall, id_stall, ex_stall;
    logic        if_flush, id_flush, ex_flush;
    logic [1:0]  forward_sel1, forward_sel2;
    logic [31:0] forward_data1, forward_data2;
    
    // Register file signals
    logic [31:0] reg_data1, reg_data2;
    
    // Instantiate IF stage
    if_stage if_stage_inst (
        .clk_i(clk_i),
        .resetn_i(resetn_i),
        .pc_src_i(ex_pc_src),
        .pc_branch_i(ex_branch_target),
        .stall_i(if_stall),
        .flush_i(if_flush),
        .pc_o(if_pc),
        .pc_plus4_o(if_pc_plus4),
        .instruction_o(if_instruction),
        .if_valid_o(if_valid),
        .imem_addr_o(imem_addr_o),
        .imem_inst_i(imem_inst_i)
    );
    
    // Instantiate IF/ID pipeline register
    if_id_reg if_id_reg_inst (
        .clk_i(clk_i),
        .resetn_i(resetn_i),
        .stall_i(if_stall),
        .flush_i(if_flush),
        .pc_i(if_pc),
        .pc_plus4_i(if_pc_plus4),
        .instruction_i(if_instruction),
        .if_valid_i(if_valid),
        .pc_o(id_pc),
        .pc_plus4_o(id_pc_plus4),
        .instruction_o(id_instruction),
        .if_valid_o(id_valid)
    );
    
    // Instantiate ID stage
    id_stage id_stage_inst (
        .clk_i(clk_i),
        .resetn_i(resetn_i),
        .instruction_i(id_instruction),
        .pc_i(id_pc),
        .pc_plus4_i(id_pc_plus4),
        .id_valid_i(id_valid),
        .stall_i(id_stall),
        .flush_i(id_flush),
        .reg_data1_i(reg_data1),
        .reg_data2_i(reg_data2),
        .reg_write_o(id_reg_write),
        .mem_to_reg_o(id_mem_to_reg),
        .mem_write_o(id_mem_write),
        .mem_read_o(id_mem_read),
        .alu_src_o(id_alu_src),
        .alu_control_o(id_alu_control),
        .branch_o(id_branch),
        .jump_o(id_jump),
        .immediate_o(id_immediate),
        .reg_data1_o(id_reg_data1),
        .reg_data2_o(id_reg_data2),
        .rs1_addr_o(id_rs1_addr),
        .rs2_addr_o(id_rs2_addr),
        .rd_addr_o(id_rd_addr),
        .rs1_read_o(id_rs1_read),
        .rs2_read_o(id_rs2_read)
    );
    
    // Instantiate ID/EX pipeline register
    id_ex_reg id_ex_reg_inst (
        .clk_i(clk_i),
        .resetn_i(resetn_i),
        .stall_i(id_stall),
        .flush_i(id_flush),
        .reg_write_i(id_reg_write),
        .mem_to_reg_i(id_mem_to_reg),
        .mem_write_i(id_mem_write),
        .mem_read_i(id_mem_read),
        .alu_src_i(id_alu_src),
        .alu_control_i(id_alu_control),
        .branch_i(id_branch),
        .jump_i(id_jump),
        .pc_i(id_pc),
        .pc_plus4_i(id_pc_plus4),
        .immediate_i(id_immediate),
        .reg_data1_i(id_reg_data1),
        .reg_data2_i(id_reg_data2),
        .rs1_addr_i(id_rs1_addr),
        .rs2_addr_i(id_rs2_addr),
        .rd_addr_i(id_rd_addr),
        .instruction_i(id_instruction),
        .id_valid_i(id_valid),
        .reg_write_o(id_ex_reg_write),
        .mem_to_reg_o(id_ex_mem_to_reg),
        .mem_write_o(id_ex_mem_write),
        .mem_read_o(id_ex_mem_read),
        .alu_src_o(id_ex_alu_src),
        .alu_control_o(id_ex_alu_control),
        .branch_o(id_ex_branch),
        .jump_o(id_ex_jump),
        .pc_o(id_ex_pc),
        .pc_plus4_o(id_ex_pc_plus4),
        .immediate_o(id_ex_immediate),
        .reg_data1_o(id_ex_reg_data1),
        .reg_data2_o(id_ex_reg_data2),
        .rs1_addr_o(id_ex_rs1_addr),
        .rs2_addr_o(id_ex_rs2_addr),
        .rd_addr_o(id_ex_rd_addr),
        .instruction_o(id_ex_instruction),
        .id_valid_o(id_ex_valid)
    );
    
    // Instantiate EX stage
    ex_stage ex_stage_inst (
        .clk_i(clk_i),
        .resetn_i(resetn_i),
        .reg_write_i(id_ex_reg_write),
        .mem_to_reg_i(id_ex_mem_to_reg),
        .mem_write_i(id_ex_mem_write),
        .mem_read_i(id_ex_mem_read),
        .alu_src_i(id_ex_alu_src),
        .alu_control_i(id_ex_alu_control),
        .branch_i(id_ex_branch),
        .jump_i(id_ex_jump),
        .pc_i(id_ex_pc),
        .pc_plus4_i(id_ex_pc_plus4),
        .immediate_i(id_ex_immediate),
        .reg_data1_i(id_ex_reg_data1),
        .reg_data2_i(id_ex_reg_data2),
        .rs1_addr_i(id_ex_rs1_addr),
        .rs2_addr_i(id_ex_rs2_addr),
        .rd_addr_i(id_ex_rd_addr),
        .instruction_i(id_ex_instruction),
        .ex_valid_i(id_ex_valid),
        .forward_data1_i(forward_data1),
        .forward_data2_i(forward_data2),
        .forward_sel1_i(forward_sel1),
        .forward_sel2_i(forward_sel2),
        .reg_write_o(ex_reg_write),
        .mem_to_reg_o(ex_mem_to_reg),
        .mem_write_o(ex_mem_write),
        .mem_read_o(ex_mem_read),
        .alu_result_o(ex_alu_result),
        .reg_data2_o(ex_reg_data2),
        .rd_addr_o(ex_rd_addr),
        .instruction_o(ex_instruction),
        .ex_valid_o(ex_valid),
        .branch_taken_o(ex_branch_taken),
        .branch_target_o(ex_branch_target),
        .pc_src_o(ex_pc_src)
    );
    
    // Instantiate EX/MEM pipeline register
    ex_mem_reg ex_mem_reg_inst (
        .clk_i(clk_i),
        .resetn_i(resetn_i),
        .stall_i(ex_stall),
        .flush_i(ex_flush),
        .reg_write_i(ex_reg_write),
        .mem_to_reg_i(ex_mem_to_reg),
        .mem_write_i(ex_mem_write),
        .mem_read_i(ex_mem_read),
        .alu_result_i(ex_alu_result),
        .reg_data2_i(ex_reg_data2),
        .rd_addr_i(ex_rd_addr),
        .instruction_i(ex_instruction),
        .ex_valid_i(ex_valid),
        .reg_write_o(mem_reg_write),
        .mem_to_reg_o(mem_mem_to_reg),
        .mem_write_o(mem_write_o),
        .mem_read_o(mem_read_o),
        .alu_result_o(mem_alu_result),
        .reg_data2_o(mem_dat_o),
        .rd_addr_o(mem_rd_addr),
        .instruction_o(mem_instruction),
        .ex_valid_o(mem_valid)
    );
    
    // Instantiate MEM stage
    mem_stage mem_stage_inst (
        .clk_i(clk_i),
        .resetn_i(resetn_i),
        .reg_write_i(mem_reg_write),
        .mem_to_reg_i(mem_mem_to_reg),
        .mem_write_i(mem_write_o),
        .mem_read_i(mem_read_o),
        .alu_result_i(mem_alu_result),
        .reg_data2_i(mem_dat_o),
        .rd_addr_i(mem_rd_addr),
        .instruction_i(mem_instruction),
        .mem_valid_i(mem_valid),
        .mem_addr_o(mem_addr_o),
        .mem_dat_i(mem_dat_i),
        .mem_wstrb_o(mem_wstrb_o),
        .mem_ack_i(mem_ack_i),
        .reg_write_o(wb_reg_write),
        .mem_data_o(wb_rd_data),
        .rd_addr_o(wb_rd_addr)
    );
    
    // Instantiate MEM/WB pipeline register
    mem_wb_reg mem_wb_reg_inst (
        .clk_i(clk_i),
        .resetn_i(resetn_i),
        .stall_i(1'b0),
        .flush_i(1'b0),
        .reg_write_i(wb_reg_write),
        .mem_to_reg_i(mem_mem_to_reg),
        .alu_result_i(mem_alu_result),
        .mem_data_i(mem_dat_i),
        .rd_addr_i(mem_rd_addr),
        .instruction_i(mem_instruction),
        .mem_valid_i(mem_valid),
    );
    
    // Instantiate WB stage
    wb_stage wb_stage_inst (
        .clk_i(clk_i),
        .resetn_i(resetn_i),
        .reg_write_i(wb_reg_write),
        .mem_to_reg_i(mem_mem_to_reg),
        .alu_result_i(mem_alu_result),
        .mem_data_i(mem_dat_i),
        .rd_addr_i(mem_rd_addr),
        .instruction_i(mem_instruction),
        .wb_valid_i(mem_valid)
    );
    
    // Instantiate register file
    register_file reg_file_inst (
        .clk_i(clk_i),
        .resetn_i(resetn_i),
        .rs1_addr_i(id_rs1_addr),
        .rs2_addr_i(id_rs2_addr),
        .rs1_data_o(reg_data1),
        .rs2_data_o(reg_data2),
        .reg_write_i(wb_reg_write),
        .rd_addr_i(wb_rd_addr),
        .rd_data_i(wb_rd_data)
    );
    
    // Instantiate hazard detection unit
    hazard_unit hazard_unit_inst (
        .id_rs1_addr_i(id_rs1_addr),
        .id_rs2_addr_i(id_rs2_addr),
        .id_rs1_read_i(id_rs1_read),
        .id_rs2_read_i(id_rs2_read),
        .ex_rd_addr_i(ex_rd_addr),
        .ex_reg_write_i(ex_reg_write),
        .ex_mem_read_i(ex_mem_read),
        .mem_rd_addr_i(mem_rd_addr),
        .mem_reg_write_i(mem_reg_write),
        .mem_mem_read_i(mem_read_o),
        .wb_rd_addr_i(wb_rd_addr),
        .wb_reg_write_i(wb_reg_write),
        .branch_taken_i(ex_branch_taken),
        .pc_stall_o(pc_stall),
        .if_stall_o(if_stall),
        .id_stall_o(id_stall),
        .ex_stall_o(ex_stall),
        .if_flush_o(if_flush),
        .id_flush_o(id_flush),
        .ex_flush_o(ex_flush)
    );
    
    // Instantiate forwarding unit
    forwarding_unit forwarding_unit_inst (
        .ex_rs1_addr_i(id_ex_rs1_addr),
        .ex_rs2_addr_i(id_ex_rs2_addr),
        .mem_rd_addr_i(mem_rd_addr),
        .mem_reg_write_i(mem_reg_write),
        .wb_rd_addr_i(wb_rd_addr),
        .wb_reg_write_i(wb_reg_write),
        .forward_sel1_o(forward_sel1),
        .forward_sel2_o(forward_sel2)
    );
    
    // Forwarding data selection
    assign forward_data1 = mem_alu_result;
    assign forward_data2 = wb_rd_data;
    
    // Outputs
    assign illegal_inst_o = 1'b0;
    
    // Tracer Integration
    `ifdef tracer
    logic [31:0] rvfi_insn;
    logic [4:0]  rvfi_rs1_addr, rvfi_rs2_addr, rvfi_rd_addr;
    logic [31:0] rvfi_rs1_rdata, rvfi_rs2_rdata, rvfi_rd_wdata;
    logic [31:0] rvfi_pc_rdata, rvfi_pc_wdata;
    logic [31:0] rvfi_mem_addr, rvfi_mem_wdata, rvfi_mem_rdata;
    logic [3:0]  rvfi_mem_rmask, rvfi_mem_wmask;
    logic        rvfi_valid;
    
    assign rvfi_insn = mem_instruction;
    assign rvfi_rs1_addr = mem_instruction[19:15];
    assign rvfi_rs2_addr = mem_instruction[24:20];
    assign rvfi_rd_addr = mem_rd_addr;
    assign rvfi_rs1_rdata = reg_data1;
    assign rvfi_rs2_rdata = reg_data2;
    assign rvfi_rd_wdata = wb_rd_data;
    assign rvfi_pc_rdata = if_pc;
    assign rvfi_pc_wdata = if_pc_plus4;
    assign rvfi_mem_addr = mem_addr_o;
    assign rvfi_mem_wdata = mem_dat_o;
    assign rvfi_mem_rdata = mem_dat_i;
    assign rvfi_mem_rmask = mem_read_o ? 4'b1111 : 4'b0000;
    assign rvfi_mem_wmask = mem_write_o ? 4'b1111 : 4'b0000;
    assign rvfi_valid = mem_valid;
    
    tracer tracer_inst (
        .clk_i(clk_i),
        .rst_ni(resetn_i),
        .hart_id_i(1),
        .rvfi_insn_t(rvfi_insn),
        .rvfi_rs1_addr_t(rvfi_rs1_addr),
        .rvfi_rs2_addr_t(rvfi_rs2_addr),
        .rvfi_mem_rmask(rvfi_mem_rmask),
        .rvfi_mem_wmask(rvfi_mem_wmask),
        .rvfi_rs1_rdata_t(rvfi_rs1_rdata),
        .rvfi_rs2_rdata_t(rvfi_rs2_rdata),
        .rvfi_rd_addr_t(rvfi_rd_addr),
        .rvfi_rd_wdata_t(rvfi_rd_wdata),
        .rvfi_pc_rdata_t(rvfi_pc_rdata),
        .rvfi_pc_wdata_t(rvfi_pc_wdata),
        .rvfi_mem_addr(rvfi_mem_addr),
        .rvfi_mem_wdata(rvfi_mem_wdata),
        .rvfi_mem_rdata(rvfi_mem_rdata),
        .rvfi_valid(rvfi_valid)
    );
    `endif

endmodule
