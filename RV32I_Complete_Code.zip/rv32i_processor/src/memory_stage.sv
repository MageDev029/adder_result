`timescale 1ns / 1ps

module memory_stage (
    input  logic        clk_i,
    input  logic        resetn_i,
    input  logic        stall_i,
    input  logic [31:0] pc_i,
    input  logic [31:0] instruction_i,
    input  logic [31:0] alu_result_i,
    input  logic [31:0] mem_write_data_i,
    input  logic [31:0] mem_read_data_i,
    input  logic        mem_ack_i,
    output logic [31:0] pc_o,
    output logic [31:0] instruction_o,
    output logic [31:0] mem_address_o,
    output logic [31:0] mem_write_data_o,
    output logic [31:0] mem_read_data_o,
    output logic        mem_write_enable_o,
    output logic [3:0]  mem_write_strobe_o,
    output logic        mem_read_enable_o
);

    // Pipeline registers
    logic [31:0] pc_reg;
    logic [31:0] instruction_reg;
    logic [31:0] alu_result_reg;
    logic [31:0] mem_write_data_reg;
    
    // Memory control signals
    logic        mem_write_enable;
    logic        mem_read_enable;
    logic [3:0]  mem_write_strobe;
    logic [2:0]  mem_size;
    
    // Pipeline registers
    always_ff @(posedge clk_i or negedge resetn_i) begin
        if (!resetn_i) begin
            pc_reg <= 32'h0;
            instruction_reg <= 32'h00000013; // NOP
            alu_result_reg <= 32'h0;
            mem_write_data_reg <= 32'h0;
        end else if (!stall_i) begin
            pc_reg <= pc_i;
            instruction_reg <= instruction_i;
            alu_result_reg <= alu_result_i;
            mem_write_data_reg <= mem_write_data_i;
        end
    end
    
    // Memory control logic
    always_comb begin
        mem_write_enable = 1'b0;
        mem_read_enable = 1'b0;
        mem_write_strobe = 4'b0000;
        mem_size = 3'b000;
        
        case (instruction_reg[6:0])
            // Load instructions
            7'b0000011: begin
                mem_read_enable = 1'b1;
                mem_size = instruction_reg[14:12];
            end
            
            // Store instructions
            7'b0100011: begin
                mem_write_enable = 1'b1;
                mem_size = instruction_reg[14:12];
                
                // Generate write strobe based on size
                case (instruction_reg[14:12])
                    3'b000: mem_write_strobe = 4'b0001 << alu_result_reg[1:0]; // SB
                    3'b001: mem_write_strobe = 4'b0011 << {alu_result_reg[1], 1'b0}; // SH
                    3'b010: mem_write_strobe = 4'b1111; // SW
                    default: mem_write_strobe = 4'b0000;
                endcase
            end
            
            default: begin
                mem_write_enable = 1'b0;
                mem_read_enable = 1'b0;
                mem_write_strobe = 4'b0000;
            end
        endcase
    end
    
    // Output assignments
    assign pc_o = pc_reg;
    assign instruction_o = instruction_reg;
    assign mem_address_o = alu_result_reg;
    assign mem_write_data_o = mem_write_data_reg;
    assign mem_read_data_o = mem_read_data_i;
    assign mem_write_enable_o = mem_write_enable;
    assign mem_write_strobe_o = mem_write_strobe;
    assign mem_read_enable_o = mem_read_enable;

endmodule
