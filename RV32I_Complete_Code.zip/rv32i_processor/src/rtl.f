# RTL file list for RV32I Processor
# Compilation order is important for proper dependency resolution

# Basic modules (no dependencies)
src/alu.sv
src/control_unit.sv
src/register_file.sv
src/hazard_detection.sv

# Pipeline stages (depend on basic modules)
src/fetch_stage.sv
src/decode_stage.sv
src/execute_stage.sv
src/memory_stage.sv
src/writeback_stage.sv

# Top-level module (depends on all other modules)
src/rv32i_top.sv
