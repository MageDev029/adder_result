`timescale 1ns / 1ps

module writeback_stage (
    input  logic        clk_i,
    input  logic        resetn_i,
    input  logic [31:0] pc_i,
    input  logic [31:0] instruction_i,
    input  logic [31:0] alu_result_i,
    input  logic [31:0] mem_read_data_i,
    output logic [31:0] pc_o,
    output logic [31:0] instruction_o,
    output logic [31:0] rd_data_o,
    output logic        reg_write_enable_o
);

    // Pipeline registers
    logic [31:0] pc_reg;
    logic [31:0] instruction_reg;
    logic [31:0] alu_result_reg;
    logic [31:0] mem_read_data_reg;
    
    // Writeback control signals
    logic        mem_to_reg;
    logic        reg_write_enable;
    logic [31:0] writeback_data;
    
    // Pipeline registers
    always_ff @(posedge clk_i or negedge resetn_i) begin
        if (!resetn_i) begin
            pc_reg <= 32'h0;
            instruction_reg <= 32'h00000013; // NOP
            alu_result_reg <= 32'h0;
            mem_read_data_reg <= 32'h0;
        end else begin
            pc_reg <= pc_i;
            instruction_reg <= instruction_i;
            alu_result_reg <= alu_result_i;
            mem_read_data_reg <= mem_read_data_i;
        end
    end
    
    // Writeback control logic
    always_comb begin
        mem_to_reg = 1'b0;
        reg_write_enable = 1'b0;
        
        case (instruction_reg[6:0])
            // LUI, AUIPC
            7'b0110111, 7'b0010111: begin
                reg_write_enable = 1'b1;
                mem_to_reg = 1'b0;
            end
            
            // JAL, JALR
            7'b1101111, 7'b1100111: begin
                reg_write_enable = 1'b1;
                mem_to_reg = 1'b0;
            end
            
            // Load instructions
            7'b0000011: begin
                reg_write_enable = 1'b1;
                mem_to_reg = 1'b1;
            end
            
            // I-type and R-type ALU instructions
            7'b0010011, 7'b0110011: begin
                reg_write_enable = 1'b1;
                mem_to_reg = 1'b0;
            end
            
            // Store and Branch instructions don't write to register
            default: begin
                reg_write_enable = 1'b0;
                mem_to_reg = 1'b0;
            end
        endcase
    end
    
    // Writeback data selection
    always_comb begin
        case (instruction_reg[6:0])
            // JAL, JALR - write PC+4
            7'b1101111, 7'b1100111: begin
                writeback_data = pc_reg + 32'd4;
            end
            
            // Load instructions - write memory data
            7'b0000011: begin
                case (instruction_reg[14:12])
                    3'b000: begin // LB
                        writeback_data = {{24{mem_read_data_reg[7]}}, mem_read_data_reg[7:0]};
                    end
                    3'b001: begin // LH
                        writeback_data = {{16{mem_read_data_reg[15]}}, mem_read_data_reg[15:0]};
                    end
                    3'b010: begin // LW
                        writeback_data = mem_read_data_reg;
                    end
                    3'b100: begin // LBU
                        writeback_data = {24'h0, mem_read_data_reg[7:0]};
                    end
                    3'b101: begin // LHU
                        writeback_data = {16'h0, mem_read_data_reg[15:0]};
                    end
                    default: writeback_data = mem_read_data_reg;
                endcase
            end
            
            // All other instructions - write ALU result
            default: begin
                writeback_data = alu_result_reg;
            end
        endcase
    end
    
    // Output assignments
    assign pc_o = pc_reg;
    assign instruction_o = instruction_reg;
    assign rd_data_o = writeback_data;
    assign reg_write_enable_o = reg_write_enable;

endmodule
