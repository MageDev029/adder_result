`timescale 1ns / 1ps

module execute_stage (
    input  logic        clk_i,
    input  logic        resetn_i,
    input  logic        stall_i,
    input  logic [31:0] pc_i,
    input  logic [31:0] instruction_i,
    input  logic [31:0] rs1_data_i,
    input  logic [31:0] rs2_data_i,
    input  logic [31:0] immediate_i,
    input  logic [2:0]  imm_type_i,
    input  logic [1:0]  forward_a_i,
    input  logic [1:0]  forward_b_i,
    output logic [31:0] pc_o,
    output logic [31:0] instruction_o,
    output logic [31:0] alu_result_o,
    output logic [31:0] mem_write_data_o,
    output logic        branch_taken_o,
    output logic [31:0] branch_target_o
);

    // Pipeline registers
    logic [31:0] pc_reg;
    logic [31:0] instruction_reg;
    
    // ALU signals
    logic [3:0]  alu_control;
    logic [31:0] alu_result;
    logic        alu_zero, alu_less_than;
    
    // Control signals
    logic        alu_src;
    logic        branch;
    logic        jump;
    logic [2:0]  branch_type;
    
    // Forwarded data
    logic [31:0] forwarded_rs1_data, forwarded_rs2_data;
    
    // Pipeline registers
    always_ff @(posedge clk_i or negedge resetn_i) begin
        if (!resetn_i) begin
            pc_reg <= 32'h0;
            instruction_reg <= 32'h00000013; // NOP
        end else if (!stall_i) begin
            pc_reg <= pc_i;
            instruction_reg <= instruction_i;
        end
    end
    
    // ALU operand selection with forwarding
    logic [31:0] alu_operand_a, alu_operand_b;
    
    // Control unit
    control_unit control_inst (
        .opcode_i(instruction_reg[6:0]),
        .funct3_i(instruction_reg[14:12]),
        .funct7_i(instruction_reg[31:25]),
        .alu_src_o(alu_src),
        .alu_control_o(alu_control),
        .branch_o(branch),
        .jump_o(jump),
        .branch_type_o(branch_type)
    );
    
    // Forwarding logic for EX stage (no EX-to-EX forwarding to avoid circular logic)
    always_comb begin
        case (forward_a_i)
            2'b00: forwarded_rs1_data = rs1_data_i;
            2'b01: forwarded_rs1_data = rs1_data_i; // No EX-to-EX forwarding
            2'b10: forwarded_rs1_data = rs1_data_i; // Forward from MEM stage (handled in top module)
            default: forwarded_rs1_data = rs1_data_i;
        endcase
        
        case (forward_b_i)
            2'b00: forwarded_rs2_data = rs2_data_i;
            2'b01: forwarded_rs2_data = rs2_data_i; // No EX-to-EX forwarding
            2'b10: forwarded_rs2_data = rs2_data_i; // Forward from MEM stage (handled in top module)
            default: forwarded_rs2_data = rs2_data_i;
        endcase
    end
    
    // ALU operand selection
    assign alu_operand_a = forwarded_rs1_data;
    assign alu_operand_b = alu_src ? immediate_i : forwarded_rs2_data;
    
    // ALU instantiation
    alu alu_inst (
        .operand_a_i(alu_operand_a),
        .operand_b_i(alu_operand_b),
        .control_i(alu_control),
        .result_o(alu_result),
        .zero_o(alu_zero),
        .less_than_o(alu_less_than)
    );
    
    // Branch decision
    always_comb begin
        branch_taken_o = 1'b0;
        case (branch_type)
            3'b000: branch_taken_o = branch && alu_zero;        // BEQ
            3'b001: branch_taken_o = branch && !alu_zero;       // BNE
            3'b100: branch_taken_o = branch && alu_less_than;   // BLT
            3'b101: branch_taken_o = branch && !alu_less_than;  // BGE
            3'b110: branch_taken_o = branch && alu_less_than;   // BLTU
            3'b111: branch_taken_o = branch && !alu_less_than;  // BGEU
            default: branch_taken_o = 1'b0;
        endcase
    end
    
    // Branch target calculation
    assign branch_target_o = branch_taken_o ? (pc_reg + immediate_i) : (pc_reg + 4);
    
    // Output assignments
    assign pc_o = pc_reg;
    assign instruction_o = instruction_reg;
    assign alu_result_o = alu_result;
    assign mem_write_data_o = forwarded_rs2_data;

endmodule
