`timescale 1ns / 1ps

module fetch_stage (
    input  logic        clk_i,
    input  logic        resetn_i,
    input  logic        stall_i,
    input  logic        flush_i,
    input  logic        branch_taken_i,
    input  logic [31:0] branch_target_i,
    input  logic [31:0] instruction_i,
    output logic [31:0] pc_o,
    output logic [31:0] instruction_o
);

    logic [31:0] pc_reg;
    logic [31:0] pc_next;
    logic [31:0] pc_plus_4;
    
    // PC increment
    assign pc_plus_4 = pc_reg + 32'd4;
    
    // PC selection
    assign pc_next = branch_taken_i ? branch_target_i : pc_plus_4;
    
    // PC register
    always_ff @(posedge clk_i or negedge resetn_i) begin
        if (!resetn_i) begin
            `ifdef tracer
            pc_reg <= 32'h80000000;  // Reset to 0x80000000 when tracer is defined
            `else
            pc_reg <= 32'h00000000;  // Reset to 0x00000000 when tracer is not defined
            `endif
        end else if (!stall_i) begin
            pc_reg <= pc_next;
        end
    end
    
    // Output assignments
    assign pc_o = pc_reg;
    assign instruction_o = flush_i ? 32'h00000013 : instruction_i; // NOP when flushed

endmodule
