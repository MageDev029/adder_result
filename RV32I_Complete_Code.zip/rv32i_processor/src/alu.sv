`timescale 1ns / 1ps

module alu (
    input  logic [31:0] operand_a_i,
    input  logic [31:0] operand_b_i,
    input  logic [3:0]  control_i,
    output logic [31:0] result_o,
    output logic        zero_o,
    output logic        less_than_o
);

    logic [31:0] result;
    logic        zero, less_than;
    
    // ALU operations
    always_comb begin
        case (control_i)
            4'b0000: result = operand_a_i + operand_b_i;                    // ADD
            4'b0001: result = operand_a_i << operand_b_i[4:0];              // SLL
            4'b0010: result = ($signed(operand_a_i) < $signed(operand_b_i)) ? 32'h1 : 32'h0; // SLT
            4'b0011: result = (operand_a_i < operand_b_i) ? 32'h1 : 32'h0;  // SLTU
            4'b0100: result = operand_a_i ^ operand_b_i;                    // XOR
            4'b0101: result = operand_a_i >> operand_b_i[4:0];              // SRL
            4'b0110: result = operand_a_i | operand_b_i;                    // OR
            4'b0111: result = operand_a_i & operand_b_i;                    // AND
            4'b1000: result = operand_a_i - operand_b_i;                    // SUB
            4'b1001: result = $signed(operand_a_i) >>> operand_b_i[4:0];    // SRA
            4'b1010: result = operand_a_i;                                  // Pass A (for LUI)
            4'b1011: result = operand_a_i + operand_b_i;                    // AUIPC
            default: result = 32'h0;
        endcase
    end
    
    // Zero flag
    assign zero = (result == 32'h0);
    
    // Less than flag (signed comparison)
    assign less_than = ($signed(operand_a_i) < $signed(operand_b_i));
    
    // Output assignments
    assign result_o = result;
    assign zero_o = zero;
    assign less_than_o = less_than;

endmodule
