`timescale 1ns / 1ps

module rv32i_top (
    input  logic        clk_i,
    input  logic        resetn_i,
    output logic        illegal_inst_o,
    output logic [31:0] imem_addr_o,
    input  logic [31:0] imem_inst_i,
    output logic [31:0] mem_addr_o,
    output logic [31:0] mem_dat_o,
    input  logic [31:0] mem_dat_i,
    output logic        mem_write_o,
    output logic [3:0]  mem_wstrb_o,
    output logic        mem_read_o,
    input  logic        mem_ack_i
);

    // Internal signals
    logic        clk;
    logic        reset_n;
    logic [31:0] pc_fetch;
    logic [31:0] pc_decode;
    logic [31:0] pc_execute;
    logic [31:0] pc_memory;
    logic [31:0] pc_writeback;
    
    // Pipeline control signals
    logic        pipeline_stall;
    logic        pipeline_flush;
    logic        branch_taken;
    logic [31:0] branch_target;
    
    // Instruction signals
    logic [31:0] instruction_fetch;
    logic [31:0] instruction_decode;
    logic [31:0] instruction_execute;
    logic [31:0] instruction_memory;
    logic [31:0] instruction_writeback;
    
    // Register file signals
    logic [4:0]  rs1_addr, rs2_addr, rd_addr;
    logic [31:0] rs1_data, rs2_data, rd_data;
    logic        reg_write_en;
    
    // ALU signals
    logic [31:0] alu_operand_a, alu_operand_b;
    logic [3:0]  alu_control;
    logic [31:0] alu_result;
    logic        alu_zero, alu_less_than;
    
    // Memory signals
    logic [31:0] mem_address;
    logic [31:0] mem_write_data_execute;
    logic [31:0] mem_write_data_memory;
    logic [31:0] mem_read_data;
    logic        mem_write_enable;
    logic [3:0]  mem_write_strobe;
    logic        mem_read_enable;
    
    // Control signals
    logic [2:0]  imm_type;
    logic [31:0] immediate;
    logic        pc_src;
    logic        reg_write_enable;
    logic        mem_to_reg;
    logic        alu_src;
    logic        branch;
    logic        jump;
    logic        illegal_instruction;
    
    // Forwarding signals
    logic [1:0]  forward_a, forward_b;
    logic [31:0] forward_rs1_data, forward_rs2_data;
    
    // Clock and reset assignment
    assign clk = clk_i;
    assign reset_n = resetn_i;
    
    // Output assignments
    assign imem_addr_o = pc_fetch;
    assign mem_addr_o = mem_address;
    assign mem_dat_o = mem_write_data_memory;
    assign mem_write_o = mem_write_enable;
    assign mem_wstrb_o = mem_write_strobe;
    assign mem_read_o = mem_read_enable;
    assign illegal_inst_o = illegal_instruction;
    
    // Fetch Stage
    fetch_stage fetch_stage_inst (
        .clk_i(clk),
        .resetn_i(reset_n),
        .stall_i(pipeline_stall),
        .flush_i(pipeline_flush),
        .branch_taken_i(branch_taken),
        .branch_target_i(branch_target),
        .instruction_i(imem_inst_i),
        .pc_o(pc_fetch),
        .instruction_o(instruction_fetch)
    );
    
    // Decode Stage
    decode_stage decode_stage_inst (
        .clk_i(clk),
        .resetn_i(reset_n),
        .stall_i(pipeline_stall),
        .pc_i(pc_fetch),
        .instruction_i(instruction_fetch),
        .pc_o(pc_decode),
        .instruction_o(instruction_decode),
        .rs1_addr_o(rs1_addr),
        .rs2_addr_o(rs2_addr),
        .rd_addr_o(rd_addr),
        .immediate_o(immediate),
        .imm_type_o(imm_type),
        .illegal_inst_o(illegal_instruction)
    );
    
    // Register File
    register_file reg_file_inst (
        .clk_i(clk),
        .resetn_i(reset_n),
        .rs1_addr_i(rs1_addr),
        .rs2_addr_i(rs2_addr),
        .rd_addr_i(rd_addr),
        .rd_data_i(rd_data),
        .write_enable_i(reg_write_enable),
        .rs1_data_o(rs1_data),
        .rs2_data_o(rs2_data)
    );
    
    // Execute Stage
    execute_stage execute_stage_inst (
        .clk_i(clk),
        .resetn_i(reset_n),
        .stall_i(pipeline_stall),
        .pc_i(pc_decode),
        .instruction_i(instruction_decode),
        .rs1_data_i(forward_rs1_data),
        .rs2_data_i(forward_rs2_data),
        .immediate_i(immediate),
        .imm_type_i(imm_type),
        .forward_a_i(forward_a),
        .forward_b_i(forward_b),
        .pc_o(pc_execute),
        .instruction_o(instruction_execute),
        .alu_result_o(alu_result),
        .mem_write_data_o(mem_write_data_execute),
        .branch_taken_o(branch_taken),
        .branch_target_o(branch_target)
    );
    
    // Memory Stage
    memory_stage memory_stage_inst (
        .clk_i(clk),
        .resetn_i(reset_n),
        .stall_i(pipeline_stall),
        .pc_i(pc_execute),
        .instruction_i(instruction_execute),
        .alu_result_i(alu_result),
        .mem_write_data_i(mem_write_data_execute),
        .mem_read_data_i(mem_dat_i),
        .mem_ack_i(mem_ack_i),
        .pc_o(pc_memory),
        .instruction_o(instruction_memory),
        .mem_address_o(mem_address),
        .mem_write_data_o(mem_write_data_memory),
        .mem_read_data_o(mem_read_data),
        .mem_write_enable_o(mem_write_enable),
        .mem_write_strobe_o(mem_write_strobe),
        .mem_read_enable_o(mem_read_enable)
    );
    
    // Writeback Stage
    writeback_stage writeback_stage_inst (
        .clk_i(clk),
        .resetn_i(reset_n),
        .pc_i(pc_memory),
        .instruction_i(instruction_memory),
        .alu_result_i(alu_result),
        .mem_read_data_i(mem_read_data),
        .pc_o(pc_writeback),
        .instruction_o(instruction_writeback),
        .rd_data_o(rd_data),
        .reg_write_enable_o(reg_write_enable)
    );
    
    // Hazard Detection Unit
    hazard_detection hazard_detection_inst (
        .rs1_addr_i(rs1_addr),
        .rs2_addr_i(rs2_addr),
        .execute_rd_addr_i(instruction_execute[11:7]),
        .memory_rd_addr_i(instruction_memory[11:7]),
        .execute_reg_write_i(instruction_execute[11:7] != 5'b0),
        .memory_reg_write_i(instruction_memory[11:7] != 5'b0),
        .execute_mem_read_i(instruction_execute[6:0] == 7'b0000011),
        .stall_o(pipeline_stall),
        .forward_a_o(forward_a),
        .forward_b_o(forward_b)
    );
    
    // Forwarding MUX - forward from later stages to earlier stages
    always_comb begin
        case (forward_a)
            2'b00: forward_rs1_data = rs1_data;
            2'b01: forward_rs1_data = 32'h0; // Forward from EX stage (handled in execute stage)
            2'b10: forward_rs1_data = mem_read_data; // Forward from MEM stage
            default: forward_rs1_data = rs1_data;
        endcase
        
        case (forward_b)
            2'b00: forward_rs2_data = rs2_data;
            2'b01: forward_rs2_data = 32'h0; // Forward from EX stage (handled in execute stage)
            2'b10: forward_rs2_data = mem_read_data; // Forward from MEM stage
            default: forward_rs2_data = rs2_data;
        endcase
    end
    
    // Tracer Integration
    `ifdef tracer
    logic [31:0] rvfi_insn;
    logic [4:0]  rvfi_rs1_addr, rvfi_rs2_addr, rvfi_rd_addr;
    logic [31:0] rvfi_rs1_rdata, rvfi_rs2_rdata, rvfi_rd_wdata;
    logic [31:0] rvfi_pc_rdata, rvfi_pc_wdata;
    logic [31:0] rvfi_mem_addr, rvfi_mem_wdata, rvfi_mem_rdata;
    logic        rvfi_valid;
    
    assign rvfi_insn = instruction_writeback;
    assign rvfi_rs1_addr = instruction_writeback[19:15];
    assign rvfi_rs2_addr = instruction_writeback[24:20];
    assign rvfi_rd_addr = instruction_writeback[11:7];
    assign rvfi_rs1_rdata = rs1_data;
    assign rvfi_rs2_rdata = rs2_data;
    assign rvfi_rd_wdata = rd_data;
    assign rvfi_pc_rdata = pc_writeback;
    assign rvfi_pc_wdata = pc_writeback + 4;
    assign rvfi_mem_addr = mem_address;
    assign rvfi_mem_wdata = mem_write_data;
    assign rvfi_mem_rdata = mem_read_data;
    assign rvfi_valid = reg_write_enable;
    
    tracer tracer_inst (
        .clk_i(clk),
        .rst_ni(reset_n),
        .hart_id_i(1),
        .rvfi_insn_t(rvfi_insn),
        .rvfi_rs1_addr_t(rvfi_rs1_addr),
        .rvfi_rs2_addr_t(rvfi_rs2_addr),
        .rvfi_rs3_addr_t(),
        .rvfi_rs3_rdata_t(),
        .rvfi_mem_rmask(),
        .rvfi_mem_wmask(),
        .rvfi_rs1_rdata_t(rvfi_rs1_rdata),
        .rvfi_rs2_rdata_t(rvfi_rs2_rdata),
        .rvfi_rd_addr_t(rvfi_rd_addr),
        .rvfi_rd_wdata_t(rvfi_rd_wdata),
        .rvfi_pc_rdata_t(rvfi_pc_rdata),
        .rvfi_pc_wdata_t(rvfi_pc_wdata),
        .rvfi_mem_addr(rvfi_mem_addr),
        .rvfi_mem_wdata(rvfi_mem_wdata),
        .rvfi_mem_rdata(rvfi_mem_rdata),
        .rvfi_valid(rvfi_valid)
    );
    `endif

endmodule
