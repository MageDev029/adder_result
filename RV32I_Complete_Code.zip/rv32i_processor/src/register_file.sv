`timescale 1ns / 1ps

module register_file (
    input  logic        clk_i,
    input  logic        resetn_i,
    input  logic [4:0]  rs1_addr_i,
    input  logic [4:0]  rs2_addr_i,
    input  logic [4:0]  rd_addr_i,
    input  logic [31:0] rd_data_i,
    input  logic        write_enable_i,
    output logic [31:0] rs1_data_o,
    output logic [31:0] rs2_data_o
);

    // 32 registers (x0-x31)
    logic [31:0] registers [0:31];
    
    // Write operation
    always_ff @(posedge clk_i or negedge resetn_i) begin
        if (!resetn_i) begin
            // Initialize all registers to zero
            for (int i = 0; i < 32; i++) begin
                registers[i] <= 32'h0;
            end
        end else if (write_enable_i && (rd_addr_i != 5'b0)) begin
            // x0 is always zero, so don't write to it
            registers[rd_addr_i] <= rd_data_i;
        end
    end
    
    // Read operations (combinational)
    assign rs1_data_o = (rs1_addr_i == 5'b0) ? 32'h0 : registers[rs1_addr_i];
    assign rs2_data_o = (rs2_addr_i == 5'b0) ? 32'h0 : registers[rs2_addr_i];

endmodule
