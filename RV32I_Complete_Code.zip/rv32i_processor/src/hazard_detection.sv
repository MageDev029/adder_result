`timescale 1ns / 1ps

module hazard_detection (
    input  logic [4:0]  rs1_addr_i,
    input  logic [4:0]  rs2_addr_i,
    input  logic [4:0]  execute_rd_addr_i,
    input  logic [4:0]  memory_rd_addr_i,
    input  logic        execute_reg_write_i,
    input  logic        memory_reg_write_i,
    input  logic        execute_mem_read_i,
    output logic        stall_o,
    output logic [1:0]  forward_a_o,
    output logic [1:0]  forward_b_o
);

    logic        stall;
    logic [1:0]  forward_a, forward_b;
    
    // Load-use hazard detection
    always_comb begin
        stall = 1'b0;
        
        // Check for load-use hazard
        if (execute_mem_read_i && 
            ((rs1_addr_i == execute_rd_addr_i && rs1_addr_i != 5'b0) ||
             (rs2_addr_i == execute_rd_addr_i && rs2_addr_i != 5'b0))) begin
            stall = 1'b1;
        end
    end
    
    // Forwarding logic for EX stage
    always_comb begin
        forward_a = 2'b00; // No forwarding
        forward_b = 2'b00; // No forwarding
        
        // Forward from EX stage
        if (execute_reg_write_i && execute_rd_addr_i != 5'b0) begin
            if (rs1_addr_i == execute_rd_addr_i) begin
                forward_a = 2'b01; // Forward from EX
            end
            if (rs2_addr_i == execute_rd_addr_i) begin
                forward_b = 2'b01; // Forward from EX
            end
        end
        
        // Forward from MEM stage (higher priority)
        if (memory_reg_write_i && memory_rd_addr_i != 5'b0) begin
            if (rs1_addr_i == memory_rd_addr_i && 
                !(execute_reg_write_i && execute_rd_addr_i == rs1_addr_i)) begin
                forward_a = 2'b10; // Forward from MEM
            end
            if (rs2_addr_i == memory_rd_addr_i && 
                !(execute_reg_write_i && execute_rd_addr_i == rs2_addr_i)) begin
                forward_b = 2'b10; // Forward from MEM
            end
        end
    end
    
    // Output assignments
    assign stall_o = stall;
    assign forward_a_o = forward_a;
    assign forward_b_o = forward_b;

endmodule
