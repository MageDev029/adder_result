`timescale 1ns / 1ps

module control_unit (
    input  logic [6:0]  opcode_i,
    input  logic [2:0]  funct3_i,
    input  logic [6:0]  funct7_i,
    output logic        alu_src_o,
    output logic [3:0]  alu_control_o,
    output logic        branch_o,
    output logic        jump_o,
    output logic [2:0]  branch_type_o
);

    logic        alu_src;
    logic [3:0]  alu_control;
    logic        branch;
    logic        jump;
    logic [2:0]  branch_type;
    
    always_comb begin
        // Default values
        alu_src = 1'b0;
        alu_control = 4'b0000;
        branch = 1'b0;
        jump = 1'b0;
        branch_type = 3'b000;
        
        case (opcode_i)
            // LUI
            7'b0110111: begin
                alu_src = 1'b1;
                alu_control = 4'b1010; // Pass immediate
            end
            
            // AUIPC
            7'b0010111: begin
                alu_src = 1'b1;
                alu_control = 4'b1011; // Add PC + immediate
            end
            
            // JAL
            7'b1101111: begin
                jump = 1'b1;
            end
            
            // JALR
            7'b1100111: begin
                jump = 1'b1;
                alu_control = 4'b0000; // ADD
            end
            
            // Branch instructions
            7'b1100011: begin
                branch = 1'b1;
                branch_type = funct3_i;
            end
            
            // Load instructions
            7'b0000011: begin
                alu_src = 1'b1;
                alu_control = 4'b0000; // ADD
            end
            
            // Store instructions
            7'b0100011: begin
                alu_src = 1'b1;
                alu_control = 4'b0000; // ADD
            end
            
            // I-type ALU instructions
            7'b0010011: begin
                alu_src = 1'b1;
                case (funct3_i)
                    3'b000: alu_control = 4'b0000; // ADDI
                    3'b001: alu_control = 4'b0001; // SLLI
                    3'b010: alu_control = 4'b0010; // SLTI
                    3'b011: alu_control = 4'b0011; // SLTIU
                    3'b100: alu_control = 4'b0100; // XORI
                    3'b101: alu_control = (funct7_i[5]) ? 4'b1001 : 4'b0101; // SRAI : SRLI
                    3'b110: alu_control = 4'b0110; // ORI
                    3'b111: alu_control = 4'b0111; // ANDI
                endcase
            end
            
            // R-type ALU instructions
            7'b0110011: begin
                alu_src = 1'b0;
                case (funct3_i)
                    3'b000: alu_control = (funct7_i[5]) ? 4'b1000 : 4'b0000; // SUB : ADD
                    3'b001: alu_control = 4'b0001; // SLL
                    3'b010: alu_control = 4'b0010; // SLT
                    3'b011: alu_control = 4'b0011; // SLTU
                    3'b100: alu_control = 4'b0100; // XOR
                    3'b101: alu_control = (funct7_i[5]) ? 4'b1001 : 4'b0101; // SRA : SRL
                    3'b110: alu_control = 4'b0110; // OR
                    3'b111: alu_control = 4'b0111; // AND
                endcase
            end
            
            default: begin
                alu_src = 1'b0;
                alu_control = 4'b0000;
                branch = 1'b0;
                jump = 1'b0;
                branch_type = 3'b000;
            end
        endcase
    end
    
    // Output assignments
    assign alu_src_o = alu_src;
    assign alu_control_o = alu_control;
    assign branch_o = branch;
    assign jump_o = jump;
    assign branch_type_o = branch_type;

endmodule
