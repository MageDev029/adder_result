`timescale 1ns / 1ps

module decode_stage (
    input  logic        clk_i,
    input  logic        resetn_i,
    input  logic        stall_i,
    input  logic [31:0] pc_i,
    input  logic [31:0] instruction_i,
    output logic [31:0] pc_o,
    output logic [31:0] instruction_o,
    output logic [4:0]  rs1_addr_o,
    output logic [4:0]  rs2_addr_o,
    output logic [4:0]  rd_addr_o,
    output logic [31:0] immediate_o,
    output logic [2:0]  imm_type_o,
    output logic        illegal_inst_o
);

    // Pipeline registers
    logic [31:0] pc_reg;
    logic [31:0] instruction_reg;
    
    // Instruction fields
    logic [6:0]  opcode;
    logic [4:0]  rs1, rs2, rd;
    logic [2:0]  funct3;
    logic [6:0]  funct7;
    
    // Immediate generation
    logic [31:0] imm_i, imm_s, imm_b, imm_u, imm_j;
    logic [31:0] immediate;
    logic [2:0]  imm_type;
    
    // Illegal instruction detection
    logic illegal_instruction;
    
    // Pipeline registers
    always_ff @(posedge clk_i or negedge resetn_i) begin
        if (!resetn_i) begin
            pc_reg <= 32'h0;
            instruction_reg <= 32'h00000013; // NOP
        end else if (!stall_i) begin
            pc_reg <= pc_i;
            instruction_reg <= instruction_i;
        end
    end
    
    // Instruction field extraction
    assign opcode = instruction_reg[6:0];
    assign rs1 = instruction_reg[19:15];
    assign rs2 = instruction_reg[24:20];
    assign rd = instruction_reg[11:7];
    assign funct3 = instruction_reg[14:12];
    assign funct7 = instruction_reg[31:25];
    
    // Immediate generation
    assign imm_i = {{20{instruction_reg[31]}}, instruction_reg[31:20]};
    assign imm_s = {{20{instruction_reg[31]}}, instruction_reg[31:25], instruction_reg[11:7]};
    assign imm_b = {{20{instruction_reg[31]}}, instruction_reg[7], instruction_reg[30:25], instruction_reg[11:8], 1'b0};
    assign imm_u = {instruction_reg[31:12], 12'b0};
    assign imm_j = {{12{instruction_reg[31]}}, instruction_reg[19:12], instruction_reg[20], instruction_reg[30:21], 1'b0};
    
    // Immediate type selection
    always_comb begin
        case (opcode)
            7'b0010011, 7'b0000011, 7'b1100111: begin // I-type, Load, JALR
                immediate = imm_i;
                imm_type = 3'b000;
            end
            7'b0100011: begin // S-type
                immediate = imm_s;
                imm_type = 3'b001;
            end
            7'b1100011: begin // B-type
                immediate = imm_b;
                imm_type = 3'b010;
            end
            7'b0110111, 7'b0010111: begin // U-type, LUI, AUIPC
                immediate = imm_u;
                imm_type = 3'b011;
            end
            7'b1101111: begin // J-type, JAL
                immediate = imm_j;
                imm_type = 3'b100;
            end
            default: begin
                immediate = 32'h0;
                imm_type = 3'b000;
            end
        endcase
    end
    
    // Illegal instruction detection
    always_comb begin
        illegal_instruction = 1'b0;
        
        case (opcode)
            7'b0110111, 7'b0010111, 7'b1101111: begin // LUI, AUIPC, JAL
                illegal_instruction = 1'b0;
            end
            7'b1100111: begin // JALR
                illegal_instruction = (funct3 != 3'b000);
            end
            7'b1100011: begin // Branch
                illegal_instruction = (funct3 > 3'b110) || (funct3 == 3'b010) || (funct3 == 3'b011);
            end
            7'b0000011: begin // Load
                illegal_instruction = (funct3 > 3'b101) || (funct3 == 3'b011);
            end
            7'b0100011: begin // Store
                illegal_instruction = (funct3 > 3'b010);
            end
            7'b0010011: begin // I-type ALU
                case (funct3)
                    3'b000, 3'b010, 3'b011, 3'b100, 3'b110, 3'b111: illegal_instruction = 1'b0;
                    3'b001, 3'b101: begin
                        illegal_instruction = (funct7 != 7'b0000000) && (funct7 != 7'b0100000);
                    end
                    default: illegal_instruction = 1'b1;
                endcase
            end
            7'b0110011: begin // R-type ALU
                case (funct3)
                    3'b000: illegal_instruction = (funct7 != 7'b0000000) && (funct7 != 7'b0100000);
                    3'b001, 3'b101: illegal_instruction = (funct7 != 7'b0000000);
                    3'b010, 3'b011: illegal_instruction = (funct7 != 7'b0000000);
                    3'b100, 3'b110, 3'b111: illegal_instruction = (funct7 != 7'b0000000);
                    default: illegal_instruction = 1'b1;
                endcase
            end
            7'b0001111: begin // FENCE
                illegal_instruction = 1'b1; // FENCE not supported
            end
            7'b1110011: begin // ECALL, EBREAK
                illegal_instruction = 1'b1; // ECALL, EBREAK not supported
            end
            default: illegal_instruction = 1'b1;
        endcase
    end
    
    // Output assignments
    assign pc_o = pc_reg;
    assign instruction_o = instruction_reg;
    assign rs1_addr_o = rs1;
    assign rs2_addr_o = rs2;
    assign rd_addr_o = rd;
    assign immediate_o = immediate;
    assign imm_type_o = imm_type;
    assign illegal_inst_o = illegal_instruction;

endmodule
