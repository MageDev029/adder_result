# RTL File List for RV32I 5-Stage Pipelined Processor
# This file contains all the SystemVerilog source files for the pipelined processor

# Main top-level module
src/rv32i_top.sv

# Pipeline stage modules
src/if_stage.sv
src/id_stage.sv
src/ex_stage.sv
src/mem_stage.sv
src/wb_stage.sv

# Supporting modules
src/register_file.sv
src/pipeline_registers.sv
src/hazard_unit.sv
src/forwarding_unit.sv

# Alternative implementations (optional)
# src/rv32i_pipelined_top.sv
# src/rv32i_top_single_cycle.sv
