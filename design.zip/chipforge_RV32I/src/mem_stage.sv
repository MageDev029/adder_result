`timescale 1ns / 1ps

module mem_stage (
    input  logic        clk_i,
    input  logic        resetn_i,
    // Control signals from EX
    input  logic        reg_write_i,
    input  logic        mem_to_reg_i,
    input  logic        mem_write_i,
    input  logic        mem_read_i,
    // Data from EX
    input  logic [31:0] alu_result_i,
    input  logic [31:0] reg_data2_i,
    input  logic [4:0]  rd_addr_i,
    input  logic [31:0] instruction_i,
    input  logic        mem_valid_i,
    // Memory interface
    output logic [31:0] mem_addr_o,
    output logic [31:0] mem_dat_o,
    input  logic [31:0] mem_dat_i,
    output logic        mem_write_o,
    output logic [3:0]  mem_wstrb_o,
    output logic        mem_read_o,
    input  logic        mem_ack_i,
    // Outputs to WB
    output logic        reg_write_o,
    output logic        mem_to_reg_o,
    output logic [31:0] alu_result_o,
    output logic [31:0] mem_data_o,
    output logic [4:0]  rd_addr_o,
    output logic [31:0] instruction_o,
    output logic        mem_valid_o
);

    // Memory interface
    assign mem_addr_o = alu_result_i;
    assign mem_dat_o = reg_data2_i;
    assign mem_write_o = mem_write_i;
    assign mem_wstrb_o = mem_write_i ? 4'b1111 : 4'b0000;
    assign mem_read_o = mem_read_i;
    
    // Outputs to WB stage
    assign reg_write_o = reg_write_i;
    assign mem_to_reg_o = mem_to_reg_i;
    assign alu_result_o = alu_result_i;
    assign mem_data_o = mem_dat_i;
    assign rd_addr_o = rd_addr_i;
    assign instruction_o = instruction_i;
    assign mem_valid_o = mem_valid_i;

endmodule
