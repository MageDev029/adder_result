`timescale 1ns / 1ps

module ex_stage (
    input  logic        clk_i,
    input  logic        resetn_i,
    // Control signals from ID
    input  logic        reg_write_i,
    input  logic        mem_to_reg_i,
    input  logic        mem_write_i,
    input  logic        mem_read_i,
    input  logic        alu_src_i,
    input  logic [3:0]  alu_control_i,
    input  logic        branch_i,
    input  logic        jump_i,
    // Data from ID
    input  logic [31:0] pc_i,
    input  logic [31:0] pc_plus4_i,
    input  logic [31:0] immediate_i,
    input  logic [31:0] reg_data1_i,
    input  logic [31:0] reg_data2_i,
    input  logic [4:0]  rs1_addr_i,
    input  logic [4:0]  rs2_addr_i,
    input  logic [4:0]  rd_addr_i,
    input  logic [31:0] instruction_i,
    input  logic        ex_valid_i,
    // Forwarding inputs
    input  logic [31:0] forward_data1_i,
    input  logic [31:0] forward_data2_i,
    input  logic [1:0]  forward_sel1_i,
    input  logic [1:0]  forward_sel2_i,
    // Outputs
    output logic        reg_write_o,
    output logic        mem_to_reg_o,
    output logic        mem_write_o,
    output logic        mem_read_o,
    output logic [31:0] alu_result_o,
    output logic [31:0] reg_data2_o,
    output logic [4:0]  rd_addr_o,
    output logic [31:0] instruction_o,
    output logic        ex_valid_o,
    // Branch resolution
    output logic        branch_taken_o,
    output logic [31:0] branch_target_o,
    output logic        pc_src_o
);

    logic [31:0] alu_src1, alu_src2;
    logic [31:0] alu_result;
    logic        branch_taken;
    logic [31:0] branch_target;
    logic [31:0] jump_target;
    
    // ALU source selection with forwarding
    always_comb begin
        case (forward_sel1_i)
            2'b00: alu_src1 = reg_data1_i;
            2'b01: alu_src1 = forward_data1_i; // Forward from MEM stage
            2'b10: alu_src1 = forward_data2_i; // Forward from WB stage
            default: alu_src1 = reg_data1_i;
        endcase
        
        case (forward_sel2_i)
            2'b00: alu_src2 = alu_src_i ? immediate_i : reg_data2_i;
            2'b01: alu_src2 = alu_src_i ? immediate_i : forward_data1_i; // Forward from MEM stage
            2'b10: alu_src2 = alu_src_i ? immediate_i : forward_data2_i; // Forward from WB stage
            default: alu_src2 = alu_src_i ? immediate_i : reg_data2_i;
        endcase
    end
    
    // ALU
    always_comb begin
        case (alu_control_i)
            4'b0000: alu_result = alu_src1 + alu_src2; // ADD
            4'b0001: alu_result = alu_src1 << alu_src2[4:0]; // SLL
            4'b0010: alu_result = ($signed(alu_src1) < $signed(alu_src2)) ? 32'h1 : 32'h0; // SLT
            4'b0011: alu_result = (alu_src1 < alu_src2) ? 32'h1 : 32'h0; // SLTU
            4'b0100: alu_result = alu_src1 ^ alu_src2; // XOR
            4'b0110: alu_result = alu_src1 | alu_src2; // OR
            4'b0111: alu_result = alu_src1 & alu_src2; // AND
            4'b1000: alu_result = alu_src1 >> alu_src2[4:0]; // SRL
            4'b1001: alu_result = $signed(alu_src1) >>> alu_src2[4:0]; // SRA
            4'b1010: alu_result = immediate_i; // Pass immediate (LUI)
            default: alu_result = 32'h0;
        endcase
    end
    
    // Branch resolution
    always_comb begin
        branch_taken = 1'b0;
        case (instruction_i[6:0])
            7'b1100011: begin // B-type
                case (instruction_i[14:12])
                    3'b000: branch_taken = (alu_src1 == alu_src2); // BEQ
                    3'b001: branch_taken = (alu_src1 != alu_src2); // BNE
                    3'b100: branch_taken = ($signed(alu_src1) < $signed(alu_src2)); // BLT
                    3'b101: branch_taken = ($signed(alu_src1) >= $signed(alu_src2)); // BGE
                    3'b110: branch_taken = (alu_src1 < alu_src2); // BLTU
                    3'b111: branch_taken = (alu_src1 >= alu_src2); // BGEU
                    default: branch_taken = 1'b0;
                endcase
            end
            7'b1101111: branch_taken = 1'b1; // JAL
            7'b1100111: branch_taken = 1'b1; // JALR
            default: branch_taken = 1'b0;
        endcase
    end
    
    // Branch target calculation
    always_comb begin
        case (instruction_i[6:0])
            7'b1100011: begin // B-type
                branch_target = pc_i + {{20{instruction_i[31]}}, instruction_i[7], instruction_i[30:25], instruction_i[11:8], 1'b0};
            end
            7'b1101111: begin // JAL
                branch_target = pc_i + {{12{instruction_i[31]}}, instruction_i[19:12], instruction_i[20], instruction_i[30:21], 1'b0};
            end
            7'b1100111: begin // JALR
                branch_target = (alu_src1 + immediate_i) & 32'hFFFFFFFE; // Clear LSB
            end
            default: branch_target = pc_i + 4;
        endcase
    end
    
    // Outputs
    assign reg_write_o = reg_write_i;
    assign mem_to_reg_o = mem_to_reg_i;
    assign mem_write_o = mem_write_i;
    assign mem_read_o = mem_read_i;
    assign alu_result_o = alu_result;
    assign reg_data2_o = (forward_sel2_i == 2'b00) ? reg_data2_i : 
                        (forward_sel2_i == 2'b01) ? forward_data1_i : forward_data2_i;
    assign rd_addr_o = rd_addr_i;
    assign instruction_o = instruction_i;
    assign ex_valid_o = ex_valid_i;
    assign branch_taken_o = branch_taken;
    assign branch_target_o = branch_target;
    assign pc_src_o = branch_taken;

endmodule
