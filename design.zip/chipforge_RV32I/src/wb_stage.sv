`timescale 1ns / 1ps

module wb_stage (
    input  logic        clk_i,
    input  logic        resetn_i,
    // Control signals from MEM
    input  logic        reg_write_i,
    input  logic        mem_to_reg_i,
    // Data from MEM
    input  logic [31:0] alu_result_i,
    input  logic [31:0] mem_data_i,
    input  logic [4:0]  rd_addr_i,
    input  logic [31:0] instruction_i,
    input  logic        wb_valid_i,
    // Register file interface
    output logic        reg_write_o,
    output logic [4:0]  rd_addr_o,
    output logic [31:0] rd_data_o
);

    logic [31:0] write_data;
    
    // Write data selection
    assign write_data = mem_to_reg_i ? mem_data_i : alu_result_i;
    
    // Outputs
    assign reg_write_o = reg_write_i;
    assign rd_addr_o = rd_addr_i;
    assign rd_data_o = write_data;

endmodule
